import {LIMITS,normalizeReport} from '../../src/protocol.mjs';
import {openDatabase,transact} from './storage.mjs';
// No age-based removal. Only a matching receipt or explicit clear removes reports.
export class OfflineQueue {
  constructor(scope,{now=()=>Date.now(),indexedDB=globalThis.indexedDB,timeoutMs=3000}={}){this.name=`framebriar-v1-${scope}`;this.now=now;this.indexedDB=indexedDB;this.timeoutMs=timeoutMs;}
  db(options={}){return openDatabase({indexedDB:this.indexedDB,name:this.name,version:2,timeoutMs:this.timeoutMs,...options,upgrade:db=>{
    if(!db.objectStoreNames?.contains('reports'))db.createObjectStore('reports',{keyPath:'report.id'});
    if(!db.objectStoreNames?.contains('migrations'))db.createObjectStore('migrations');
  }});}
  async transaction(mode,fn,options={}){
    const db=await this.db(options);try{return await transact(db,'reports',mode,(tx,done,fail)=>fn(tx.objectStore('reports'),done,fail),{timeoutMs:this.timeoutMs,...options});}finally{db.close();}
  }
  all(){return this.transaction('readonly',(s,done)=>{const r=s.getAll();r.onsuccess=()=>done(r.result);});}
  remove(id){return this.transaction('readwrite',s=>s.delete(id));}
  clear(){return this.transaction('readwrite',s=>s.clear());}
  async prune(){} // Backward-compatible method; never expires unsent data.
  defer(id,{attempts,nextAttemptAt,code}){return this.transaction('readwrite',s=>{const r=s.get(id);r.onsuccess=()=>{if(r.result)s.put({...r.result,attempts,nextAttemptAt,code});};});}
  async capacity(){const rows=await this.all();return {items:rows.length,bytes:rows.reduce((n,x)=>n+(x.blob?.size??0),0),maxItems:LIMITS.queueItems,maxBytes:LIMITS.queueBytes,retention:'until-delivered-or-cleared'};}
  canonical(item,migration=false){
    const report=normalizeReport(structuredClone(item.report)),blob=item.blob;
    if(report.media===null?blob!==null:!(blob instanceof Blob)||blob.size!==report.media.bytes||blob.type!==report.media.type)throw Error('Invalid local feedback media');
    return {report,blob,queuedAt:migration&&Number.isFinite(item.queuedAt)?item.queuedAt:this.now(),
      attempts:migration&&Number.isInteger(item.attempts)?Math.max(0,Math.min(32,item.attempts)):0,
      nextAttemptAt:migration&&Number.isFinite(item.nextAttemptAt)?item.nextAttemptAt:0,
      ...(migration&&['access-required','quota','network','invalid-ack','unavailable','permanent'].includes(item.code)?{code:item.code}:{})};
  }
  add(item,options={}){
    const canonical=this.canonical(item),{report,blob}=canonical;
    return this.transaction('readwrite',(s,_done,fail)=>{
      const r=s.getAll();r.onsuccess=()=>{
        const rows=r.result,existing=rows.find(x=>x.report.id===report.id);
        if(existing){if(JSON.stringify(existing.report)!==JSON.stringify(report))fail(Error('Local feedback identity conflict'));return;}
        if(rows.length>=LIMITS.queueItems||rows.reduce((n,x)=>n+(x.blob?.size??0),0)+(blob?.size??0)>LIMITS.queueBytes){fail(Object.assign(Error('Local feedback storage is full'),{code:'storage-full'}));return;}
        s.put(canonical);
      };
    },options);
  }
  async importedIds(source,options={}){
    const db=await this.db(options);try{return await transact(db,'migrations','readonly',(tx,done)=>{const r=tx.objectStore('migrations').get(source);r.onsuccess=()=>done(Array.isArray(r.result?.ids)?r.result.ids:[]);},{timeoutMs:this.timeoutMs,...options});}finally{db.close();}
  }
  // Atomic import + marker prevents reimport after delivery/clear. Never deletes donor DB.
  async importLegacy(source,items,options={}){
    const values=items.map(x=>this.canonical(x,true));
    const db=await this.db(options);try{return await transact(db,['reports','migrations'],'readwrite',(tx,done,fail)=>{
      const reports=tx.objectStore('reports'),marks=tx.objectStore('migrations'),read=marks.get(source);
      read.onsuccess=()=>{
        const imported=Array.isArray(read.result?.ids)?read.result.ids:[];
        const fresh=values.filter(x=>!imported.includes(x.report.id));
        if(!fresh.length){done({imported:0,alreadyImported:true});return;}
        if(imported.length+fresh.length>1024){fail(Object.assign(Error('Legacy recovery history full'),{code:'migration-full'}));return;}
        const request=reports.getAll();request.onsuccess=()=>{
          const rows=request.result,newRows=[];let bytes=rows.reduce((n,x)=>n+(x.blob?.size??0),0);
          for(const item of fresh){const prior=rows.find(x=>x.report.id===item.report.id)||newRows.find(x=>x.report.id===item.report.id);
            if(prior){if(JSON.stringify(prior.report)!==JSON.stringify(item.report)){fail(Error('Local feedback identity conflict'));return;}continue;}
            newRows.push(item);bytes+=item.blob?.size??0;
          }
          if(rows.length+newRows.length>LIMITS.queueItems||bytes>LIMITS.queueBytes){fail(Object.assign(Error('Local feedback storage is full'),{code:'storage-full'}));return;}
          for(const item of newRows)reports.put(item);marks.put({ids:[...new Set([...imported,...fresh.map(x=>x.report.id)])]},source);done({imported:newRows.length,alreadyImported:false});
        };
      };
    },{timeoutMs:this.timeoutMs,...options});}finally{db.close();}
  }
}
