// Optional launcher/hotkey over the shared headless lifecycle. Game owns pixels/HUD.
import {createFeedbackController} from './feedback-controller.mjs';
export function mountFeedbackTrigger({enabled=false,capture,openReview,canCapture=()=>true,
  onError=()=>{},placement='bottom-right',hotkey='F8',label='Feedback',parent,launcher=true,offset={x:16,y:16},safeArea=false}) {
  if(!enabled){const noCapture=()=>false;return {disabled:true,trigger:noCapture,openFeedback:noCapture,destroy(){}};}
  if(typeof capture!=='function'||typeof openReview!=='function')throw Error('Capture and review callbacks are required.');
  const placementStyle=(corner,inset,useSafeArea)=>{
    if(!['bottom-right','bottom-left','top-right','top-left'].includes(corner)||
      !inset||![inset.x,inset.y].every(v=>Number.isFinite(v)&&v>=0&&v<=1024)||typeof useSafeArea!=='boolean')
      throw Error('Invalid feedback placement.');
    const [vertical,horizontal]=corner.split('-');
    const distance=(side,value)=>useSafeArea?`calc(${value}px + env(safe-area-inset-${side}, 0px))`:`${value}px`;
    return {top:'',bottom:'',left:'',right:'',[vertical]:distance(vertical,inset.y),[horizontal]:distance(horizontal,inset.x)};
  };
  let layout={placement,offset:{...offset},safeArea};
  const initialStyle=placementStyle(placement,offset,safeArea);
  if(hotkey!==false&&!/^F(?:[1-9]|1[0-2])$/.test(hotkey))throw Error('Choose a function-key hotkey.');
  const button=document.createElement('button');button.type='button';button.textContent=label;
  const accessibleLabel=hotkey===false?label:`${label} (${hotkey})`;
  button.setAttribute('aria-label',accessibleLabel);button.title=accessibleLabel;
  Object.assign(button.style,{...initialStyle,position:'fixed',zIndex:'1000',
    padding:'8px 12px',borderRadius:'20px',border:'1px solid #8294ac',background:'#172337',color:'#fff',font:'13px system-ui',cursor:'pointer'});
  let destroyed=false;
  const controller=createFeedbackController({enabled:true,capture,openReview,canCapture,onError,
    onActiveChange:active=>{if(!destroyed)button.disabled=active;}});
  const trigger=()=>controller.openFeedback();
  const setPlacement=(options={})=>{
    if(destroyed)return false;
    const next={...layout,...options},style=placementStyle(next.placement,next.offset,next.safeArea);
    layout={...next,offset:{...next.offset}};Object.assign(button.style,style);return true;
  };
  const key=event=>{
    const target=event.target;
    if(event.key!==hotkey||event.repeat||event.defaultPrevented||event.altKey||event.ctrlKey||event.metaKey||event.shiftKey||
      target?.isContentEditable||['INPUT','TEXTAREA','SELECT'].includes(target?.tagName))return;
    if(controller.active||destroyed)return;
    if(trigger()){event.preventDefault();event.stopImmediatePropagation();}
  };
  button.addEventListener('pointerdown',event=>event.stopPropagation());
  button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();trigger();});
  if(hotkey!==false)document.addEventListener('keydown',key,true);if(launcher)(parent??document.body).append(button);
  return {button:launcher?button:undefined,trigger,openFeedback:trigger,setPlacement,destroy(){if(destroyed)return;destroyed=true;if(hotkey!==false)document.removeEventListener('keydown',key,true);
    try{controller.destroy();}finally{button.remove();}}};
}
