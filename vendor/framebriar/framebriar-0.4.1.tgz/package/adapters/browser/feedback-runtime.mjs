// Optional private-host seam. Missing config fails closed; never a package token.
export const FEEDBACK_ENDPOINT='https://framebriar-masra91-poc.azurewebsites.net/api';
export async function loadFeedbackRuntime({gameId,buildSha,fetchImpl=fetch,now=()=>Date.now()}) {
  const disabled=Object.freeze({enabled:false});
  const match=value=>value?.v===1 && value.enabled===true && value.gameId===gameId &&
    value.buildSha===buildSha && value.endpoint===FEEDBACK_ENDPOINT;
  const options={cache:'no-store',credentials:'omit',redirect:'error'};
  try {
    const response=await fetchImpl('/framebriar/runtime',{...options,signal:AbortSignal.timeout(10000)});
    if(!response.ok)return disabled;
    const config=await response.json();if(!match(config))return disabled;
    let access,generation=0;
    return Object.freeze({enabled:true,endpoint:FEEDBACK_ENDPOINT,async getToken(){
      if(access && Date.parse(access.expiresAt)>now())return access.token;
      access=undefined;
      const ticket=generation;
      try {
        const result=await fetchImpl('/framebriar/access',{...options,method:'POST',
          headers:{'content-type':'application/json'},body:JSON.stringify({v:1,gameId,buildSha}),signal:AbortSignal.timeout(10000)});
        if(!result.ok || ticket!==generation)return undefined;
        const value=await result.json();
        if(ticket!==generation || !match(value) || !Number.isFinite(Date.parse(value.expiresAt)) || Date.parse(value.expiresAt)<=now() ||
          typeof value.token!=='string' || !/^[A-Za-z0-9_-]{43}$/.test(value.token))return undefined;
        access={token:value.token,expiresAt:value.expiresAt};return access.token;
      } catch {return undefined;}
    },clearAccess(){generation++;access=undefined;}});
  } catch {return disabled;}
}
