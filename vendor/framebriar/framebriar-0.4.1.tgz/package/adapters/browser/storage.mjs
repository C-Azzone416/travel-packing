// Bounded IDB operations. A timed-out commit may be uncertain: retry the same UUID.
const failure=code=>Object.assign(new Error(code==='storage-full'?'Local feedback storage is full':'Local storage unavailable'),{code});
const cancelled=()=>new DOMException('Local save cancelled','AbortError');
export function openDatabase({indexedDB=globalThis.indexedDB,name,version=1,upgrade,signal,timeoutMs=3000}){
  return new Promise((resolve,reject)=>{
    if(!indexedDB||signal?.aborted){reject(signal?.aborted?cancelled():failure('storage-unavailable'));return;}
    let done=false,request,timer;
    const end=(error,db)=>{if(done){db?.close();return;}done=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);error?reject(error):resolve(db);};
    const abort=()=>end(cancelled());signal?.addEventListener('abort',abort,{once:true});
    timer=setTimeout(()=>end(failure('storage-timeout')),timeoutMs);
    try{request=version===null?indexedDB.open(name):indexedDB.open(name,version);
      request.onupgradeneeded=()=>{if(done){request.transaction?.abort();return;}try{upgrade?.(request.result,request.transaction);}catch{request.transaction?.abort();end(failure('storage-unavailable'));}};
      request.onerror=request.onblocked=()=>end(failure('storage-unavailable'));
      request.onsuccess=()=>end(null,request.result);
    }catch{end(failure('storage-unavailable'));}
  });
}
export function transact(db,stores,mode,body,{signal,timeoutMs=3000}={}){
  return new Promise((resolve,reject)=>{
    if(signal?.aborted){reject(cancelled());return;}
    let tx,done=false,result,error,timer,fallback;
    const end=e=>{if(done)return;done=true;clearTimeout(timer);clearTimeout(fallback);signal?.removeEventListener('abort',abort);e?reject(e):resolve(result);};
    const stop=e=>{error=e;try{tx.abort();}catch{/* Completion can already be queued. */}
      fallback??=setTimeout(()=>end(failure('storage-uncertain')),50);};
    const abort=()=>stop(cancelled());
    try{tx=db.transaction(stores,mode);
      tx.oncomplete=()=>end();tx.onerror=tx.onabort=()=>end(error||failure('storage-unavailable'));
      signal?.addEventListener('abort',abort,{once:true});
      timer=setTimeout(()=>stop(failure('storage-timeout')),timeoutMs);
      if(signal?.aborted){abort();return;}
      body(tx,v=>{result=v;},stop);
    }catch{end(failure('storage-unavailable'));}
  });
}
