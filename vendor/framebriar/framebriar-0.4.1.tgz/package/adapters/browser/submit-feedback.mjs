// Explicit one-shot transport. Host owns review, access and retained retry state.
import {LIMITS, normalizeReport} from '../../src/protocol.mjs';
export class FeedbackSubmitError extends Error {
  constructor(code,message){super(message);this.name='FeedbackSubmitError';this.code=code;}
}
const fail=(code,message)=>{throw new FeedbackSubmitError(code,message);};
const requireValue=(ok,code,message)=>{if(!ok)fail(code,message);};
const hash=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
export async function sendPreparedFeedback({report,media,endpoint,getToken,onProgress=()=>{},signal}) {
  let frozen,url;
  try {frozen=normalizeReport(structuredClone(report));url=new URL(endpoint);}
  catch {fail('invalid-input','Invalid reviewed report or intake URL.');}
  requireValue(url.protocol==='https:' && !url.username && !url.password && !url.search && !url.hash,
    'invalid-endpoint','A credential-free HTTPS intake URL is required.');
  requireValue(typeof getToken==='function','access-required','Approved feedback access is unavailable.');
  const textOnly=frozen.media===null;
  requireValue(textOnly?media===null:media instanceof Blob && media.type==='image/png' && media.size>0 && media.size<=LIMITS.media,
    'invalid-media','A reviewed PNG up to 8 MiB is required.');
  const progress=phase=>{try{onProgress(Object.freeze({phase,reportId:frozen.id}));}catch{/* UI cannot change delivery. */}};
  const checkAbort=()=>{if(signal?.aborted)fail('cancelled','Submission cancelled; retry this same report to resolve uncertain delivery.');};
  checkAbort();progress('validating');
  const bytes=textOnly?null:await media.arrayBuffer();checkAbort();
  requireValue(textOnly||(frozen.media.type==='image/png' && frozen.media.bytes===media.size && frozen.media.sha256===await hash(bytes)),
    'invalid-media','Reviewed PNG length or hash does not match the report.');
  checkAbort();progress('authorizing');
  let token;
  try {token=await getToken();}catch {fail('access-required','Approved feedback access is unavailable.');}
  checkAbort();
  requireValue(typeof token==='string' && /^[A-Za-z0-9_-]{16,256}$/.test(token),
    'access-required','Approved feedback access is unavailable.');
  const body=JSON.stringify(frozen),base=url.href.replace(/\/$/,'')+'/v1/reports';
  async function request(path,options) {
    checkAbort();let response;
    const timeout=AbortSignal.timeout(30000);
    try {response=await fetch(base+path,{...options,redirect:'error',
      signal:signal?AbortSignal.any([signal,timeout]):timeout,
      headers:{...options.headers,authorization:`Bearer ${token}`}});}
    catch {checkAbort();fail('network','Delivery could not be confirmed. Retry this same reviewed report.');}
    checkAbort();
    if(!response.ok){
      const status=response.status;
      await response.body?.cancel();
      if(status===401||status===403)fail('access-required','Feedback access is missing, expired or not permitted for this game.');
      if(status===409)fail('conflict','This report conflicts with an existing submission. Keep it for review.');
      if(status===429||status===503){
        const raw=response.headers.get('retry-after');
        const seconds=raw&&/^\d+$/.test(raw)?Number(raw):NaN;
        const delay=Number.isFinite(seconds)?seconds*1000:raw?Date.parse(raw)-Date.now():0;
        const error=new FeedbackSubmitError(status===429?'quota':'unavailable','Feedback is temporarily unavailable.');
        error.retryAfterMs=Math.min(86400000,Math.max(0,Number.isFinite(delay)?delay:0));throw error;
      }
      if(status>=500||status===408)fail('unavailable','Feedback is temporarily unavailable.');
      if(status>=400&&status<500)fail('permanent','The service rejected this report.');
      fail('rejected','The service did not accept this request. Keep the reviewed report.');
    }
    try {return await response.json();}catch {fail('invalid-ack','Delivery acknowledgement is invalid. Keep this report for retry.');}
  }
  try {
    progress('preparing');
    let ack=await request('',{method:'POST',headers:{'content-type':'application/json'},body});
    requireValue(ack?.id===frozen.id,'invalid-ack','Delivery acknowledgement does not match this report.');
    if(ack.status==='pending') {
      requireValue(!textOnly,'invalid-ack','Text-only feedback cannot require media upload.');
      requireValue(typeof ack.ticket==='string' && /^[A-Za-z0-9_-]{43}$/.test(ack.ticket),
        'invalid-ack','Upload authorization is invalid. Keep this report for retry.');
      progress('uploading');
      ack=await request(`/${frozen.id}/media`,{method:'PUT',headers:{'content-type':'image/png','x-upload-ticket':ack.ticket},body:new Blob([bytes],{type:'image/png'})});
    }
    requireValue(ack?.id===frozen.id && ['ready','processed'].includes(ack.status),
      'invalid-ack','Delivery has not been confirmed for this report. Keep it for retry.');
    requireValue(ack.gameId===undefined || ack.gameId===frozen.gameId,'invalid-ack','Delivery game does not match this report.');
    progress('received');
    // Return only validated fields; never an arbitrary remote body or token.
    return Object.freeze({id:frozen.id,status:ack.status,gameId:frozen.gameId});
  } finally {token=undefined;}
}
