import {LIMITS,normalizeReport} from '../../src/protocol.mjs';
import {openDatabase,transact} from './storage.mjs';
const sha=async blob=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer())),x=>x.toString(16).padStart(2,'0')).join('');
const build=x=>typeof x==='string'&&/^[a-f0-9]{7,40}$/.test(x);
async function sources(indexedDB,prefix,selected,signal){
  if(typeof indexedDB?.databases!=='function')return {unsupported:true,names:[]};
  const list=await new Promise((resolve,reject)=>{
    let timer;const abort=()=>finish(new DOMException('Migration cancelled','AbortError'));
    const finish=(error,value)=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
    if(signal?.aborted){abort();return;}signal?.addEventListener('abort',abort,{once:true});
    timer=setTimeout(()=>finish(Error('Inventory unavailable')),3000);
    Promise.resolve().then(()=>indexedDB.databases()).then(v=>finish(null,v),finish);
  });
  const names=list.map(x=>x.name).filter(x=>typeof x==='string'&&x.startsWith(prefix)&&build(x.slice(prefix.length))&&(!selected||selected.includes(x.slice(prefix.length)))).sort();
  if(names.length>32)throw Error('Too many legacy stores; explicit recovery required');
  return {unsupported:false,names};
}
async function read(indexedDB,name,object,signal){
  // Name came from IDB inventory. Never create a missing legacy database.
  const db=await openDatabase({indexedDB,name,version:null,signal,upgrade:(_db,tx)=>{tx.abort();throw Error('Legacy store absent');}});
  try{return await transact(db,object,'readonly',(tx,done)=>{
    const req=object==='enrollment'?tx.objectStore(object).get('current'):tx.objectStore(object).getAll(undefined,LIMITS.queueItems+1);
    req.onsuccess=()=>done(req.result);
  },{signal});}finally{db.close();}
}
export async function migrateLegacyOutbox({endpoint,gameId,queue,indexedDB=globalThis.indexedDB,buildShas,signal}){
  const prefix=`framebriar-v1-outbox-${encodeURIComponent(endpoint.replace(/\/$/,''))}-${gameId}-`;
  const found=await sources(indexedDB,prefix,buildShas,signal),result={imported:0,alreadyImported:0,blocked:[],sourcePreserved:true,unsupported:found.unsupported};
  let hashedBytes=0;
  for(const name of found.names){
    if(signal?.aborted)throw new DOMException('Migration cancelled','AbortError');
    try{
      const ids=await queue.importedIds(name,{signal});
      const rows=await read(indexedDB,name,'reports',signal);if(!Array.isArray(rows)||rows.length>LIMITS.queueItems)throw Error('Legacy store exceeds bound');
      const fresh=rows.filter(x=>!ids.includes(x.report?.id));
      if(!fresh.length){result.alreadyImported++;continue;}
      let size=0;for(const row of fresh){
        const report=normalizeReport(row.report);
        if(report.gameId!==gameId||report.buildSha!==name.slice(prefix.length)||JSON.stringify(report)!==JSON.stringify(row.report))throw Error('Legacy scope mismatch');
        if(report.media===null?row.blob!==null:!(row.blob instanceof Blob)||row.blob.size!==report.media.bytes||row.blob.type!==report.media.type)throw Error('Legacy bytes mismatch');
        size+=row.blob?.size??0;if(size>LIMITS.queueBytes)throw Error('Legacy store exceeds bound');
        hashedBytes+=row.blob?.size??0;if(hashedBytes>LIMITS.queueBytes)throw Object.assign(Error('Recovery batch full'),{code:'migration-batch'});
        if(report.media!==null&&await sha(row.blob)!==report.media.sha256)throw Error('Legacy hash mismatch');
      }
      const saved=await queue.importLegacy(name,fresh,{signal});result.imported+=saved.imported;if(saved.alreadyImported)result.alreadyImported++;
    }catch(e){if(signal?.aborted)throw e;result.blocked.push({buildSha:name.slice(prefix.length),reason:e?.code==='storage-full'?'capacity':e?.code==='migration-batch'?'batch-limit':'unavailable-or-invalid'});}
  }
  return result;
}
export async function migrateLegacyEnrollment({endpoint,gameId,store,indexedDB=globalThis.indexedDB,buildSha,signal,crypto=globalThis.crypto}){
  const current=await store.read();if(current.revision!==0||current.session||current.notice)return {state:'already-initialized',sourcePreserved:true};
  const prefix=`framebriar-enrollment-v1-${encodeURIComponent(endpoint)}-${gameId}-`,found=await sources(indexedDB,prefix,buildSha?[buildSha]:undefined,signal);
  if(found.unsupported)return {state:'inventory-unavailable',sourcePreserved:true};
  const candidates=[];
  for(const name of found.names){
    const record=await read(indexedDB,name,'enrollment',signal);if(!record?.ciphertext)continue;
    if(record.ciphertext.byteLength>2048||record.iv?.byteLength!==12)throw Error('Legacy enrollment invalid');
    const oldBuild=name.slice(prefix.length),scope=`${endpoint}|${gameId}|${oldBuild}`;
    const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:record.iv,additionalData:new TextEncoder().encode(scope)},record.key,record.ciphertext);
    const value=JSON.parse(new TextDecoder().decode(plain));
    if(!/^[A-Za-z0-9_-]{43}$/.test(value.refreshToken??'')||!Number.isFinite(Date.parse(value.expiresAt)))throw Error('Legacy enrollment invalid');
    candidates.push(value);
  }
  // Several different families may represent different people. Never guess which to activate.
  const unique=candidates.filter((x,i,a)=>a.findIndex(y=>y.refreshToken===x.refreshToken&&y.expiresAt===x.expiresAt)===i);
  if(unique.length>1)return {state:'selection-required',sourcePreserved:true};
  if(!unique.length)return {state:'none',sourcePreserved:true};
  if(signal?.aborted)throw new DOMException('Migration cancelled','AbortError');
  return {state:await store.importLegacySession(unique[0])?'imported':'already-initialized',sourcePreserved:true};
}
