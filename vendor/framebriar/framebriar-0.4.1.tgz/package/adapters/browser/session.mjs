// Feedback ↔ telemetry correlation helpers. Contract: docs/correlation.md.
import {pageSessionId,setPageSessionId} from './telemetry.mjs';
export {pageSessionId,setPageSessionId};
// Fields to merge into the capture context when feedback opens: the shared session, the
// active span (if any) and the host's human version.
export function correlationContext({telemetry,appVersion}={}){
  const out={sessionId:telemetry?.sessionId??pageSessionId()};
  const ctx=telemetry?.activeContext?.();
  if(ctx&&/^[a-f0-9]{32}$/.test(ctx.traceId)&&/^[a-f0-9]{16}$/.test(ctx.spanId)&&!/^0+$/.test(ctx.traceId))Object.assign(out,{traceId:ctx.traceId,spanId:ctx.spanId});
  if(appVersion!=null){
    if(typeof appVersion!=='string'||!/^[A-Za-z0-9._+-]{1,40}$/.test(appVersion))throw Error('Invalid app version');
    out.appVersion=appVersion;
  }
  return out;
}
