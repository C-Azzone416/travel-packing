import {openDatabase,transact} from './storage.mjs';
// Nonextractable AES key + ciphertext; same-origin code can still use that key.
const MONTH=30*86400000,encoder=new TextEncoder();
const unavailable=()=>new Error('Enrollment storage unavailable');
export function createEnrollmentStore({endpoint,gameId,indexedDB=globalThis.indexedDB,
  crypto=globalThis.crypto,now=()=>Date.now(),BroadcastChannel=globalThis.BroadcastChannel,timeoutMs=3000}={}){
  const scope=`${endpoint}|${gameId}`,name=`framebriar-enrollment-v2-${encodeURIComponent(endpoint)}-${gameId}`;
  let channel;const listeners=new Set();
  if(BroadcastChannel)try{channel=new BroadcastChannel(name);channel.onmessage=e=>{if(Number.isSafeInteger(e.data?.revision))for(const fn of listeners)try{fn(e.data.revision);}catch{}};}catch{}
  async function transaction(mode,fn){
    if(!crypto?.subtle)throw unavailable();
    const db=await openDatabase({indexedDB,name,timeoutMs,upgrade:db=>db.createObjectStore('enrollment')});
    try{return await transact(db,'enrollment',mode,(tx,done,fail)=>{
      const object=tx.objectStore('enrollment'),r=object.get('current');r.onsuccess=()=>{try{done(fn(r.result??{revision:0},object));}catch{fail(unavailable());}};
    },{timeoutMs});}finally{db.close();}
  }
  const valid=s=>s&&/^[A-Za-z0-9_-]{43}$/.test(s.refreshToken||'')&&typeof s.expiresAt==='string'&&Number.isFinite(Date.parse(s.expiresAt))&&Date.parse(s.expiresAt)<=now()+MONTH;
  const notify=revision=>{if(revision!==null)channel?.postMessage({revision});};
  async function encrypted(session){
    const key=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']),iv=crypto.getRandomValues(new Uint8Array(12));
    const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:encoder.encode(scope)},key,encoder.encode(JSON.stringify({refreshToken:session.refreshToken,expiresAt:session.expiresAt})));
    return {key,iv,ciphertext};
  }
  return Object.freeze({name,
    async read(){try{
      const record=await transaction('readonly',x=>x);if(!Number.isSafeInteger(record.revision)||record.revision<0)throw unavailable();
      const notice=record.notice&&['expired','access-required','connection-uncertain'].includes(record.notice.state)?{state:record.notice.state,expiresAt:record.notice.expiresAt??null,enrolled:record.notice.enrolled!==false}:undefined;
      if(!record.ciphertext)return {revision:record.revision,session:null,...(notice?{notice}:{})};
      if(record.ciphertext.byteLength>2048||record.iv?.byteLength!==12)throw unavailable();
      const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:record.iv,additionalData:encoder.encode(scope)},record.key,record.ciphertext);
      const s=JSON.parse(new TextDecoder().decode(plain));if(!valid(s))throw unavailable();
      return {revision:record.revision,session:{refreshToken:s.refreshToken,expiresAt:s.expiresAt}};
    }catch{throw unavailable();}},
    async reset({expectedRevision,notice}={}){
      const safeNotice=notice&&['expired','access-required','connection-uncertain'].includes(notice.state)?{state:notice.state,expiresAt:Number.isFinite(Date.parse(notice.expiresAt))?notice.expiresAt:null,enrolled:notice.enrolled!==false}:null;
      const revision=await transaction('readwrite',(old,db)=>{
        if(!Number.isSafeInteger(old.revision)||old.revision<0)throw unavailable();
        if(expectedRevision!==undefined&&old.revision!==expectedRevision)return null;
        const revision=old.revision+1;if(!Number.isSafeInteger(revision))throw unavailable();
        db.put({revision,...(safeNotice?{notice:safeNotice}:{})},'current');return revision;
      });notify(revision);return revision;
    },
    async write(session,revision){try{
      if(!valid(session)||Date.parse(session.expiresAt)<=now()||!Number.isSafeInteger(revision))throw unavailable();
      const box=await encrypted(session);
      return await transaction('readwrite',(old,db)=>{if(old.revision!==revision)return false;db.put({revision,...box},'current');return true;});
    }catch{throw unavailable();}},
    // Fresh target only. Explicit clear/replacement/expiry can never be undone by migration.
    async importLegacySession(session){
      if(!valid(session))throw unavailable();
      const expired=Date.parse(session.expiresAt)<=now(),box=expired?null:await encrypted(session);
      const result=await transaction('readwrite',(old,db)=>{
        if(old.revision!==0||old.ciphertext||old.notice)return false;
        db.put({revision:1,...(expired?{notice:{state:'expired',expiresAt:session.expiresAt}}:box)},'current');return true;
      });if(result)notify(1);return result;
    },
    subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},
    close(){listeners.clear();channel?.close();channel=undefined;},
  });
}
