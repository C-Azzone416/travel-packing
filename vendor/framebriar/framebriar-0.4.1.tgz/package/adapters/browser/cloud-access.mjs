// Optional invitation/session adapter. No URL, storage, queue, or logging of secrets.
// connect() is an explicit user action. Periodic refresh begins only after it succeeds.
import {FEEDBACK_ENDPOINT} from './feedback-runtime.mjs';

export function createCloudAccess({gameId,buildSha,endpoint=FEEDBACK_ENDPOINT,fetchImpl=fetch,
  now=()=>Date.now(),setTimer=setTimeout,clearTimer=clearTimeout,onAccessRequired=()=>{}}){
  if(endpoint!==FEEDBACK_ENDPOINT||!/^[a-z0-9-]{1,60}$/.test(gameId)||!/^[a-f0-9]{40}$/.test(buildSha))throw Error('Invalid access configuration');
  let session,timer,generation=0,inflight,controller;
  const notify=()=>{try{onAccessRequired();}catch{/* UI errors never restore or expose access. */}};
  const valid=value=>value?.v===1&&value.gameId===gameId&&value.buildSha===buildSha&&
    /^[A-Za-z0-9_-]{43}$/.test(value.token||'')&&/^[A-Za-z0-9_-]{43}$/.test(value.refreshToken||'')&&
    Number.isFinite(Date.parse(value.expiresAt))&&Date.parse(value.expiresAt)>now()&&
    Date.parse(value.expiresAt)<=now()+3600000&&Date.parse(value.refreshExpiresAt)>=Date.parse(value.expiresAt);
  function clearAccess(){generation++;session=undefined;clearTimer(timer);timer=undefined;controller?.abort();controller=undefined;inflight=undefined;}
  function schedule(){
    clearTimer(timer);
    if(session){
      const end=Date.parse(session.refreshExpiresAt),expiry=Date.parse(session.expiresAt);
      timer=setTimer(()=>{void refresh();},Math.max(1000,(expiry>=end?end:expiry-4*60000)-now()));
    }
  }
  async function request(action,body,ticket){
    const abort=new AbortController();controller=abort;
    try{
      const response=await fetchImpl(`${endpoint}/v1/access/${action}`,{method:'POST',credentials:'omit',
        cache:'no-store',redirect:'error',headers:{'content-type':'application/json'},
        body:JSON.stringify({v:1,...body}),signal:AbortSignal.any([abort.signal,AbortSignal.timeout(10000)])});
      if(ticket!==generation)return undefined;
      if(!response.ok)throw Error('Access unavailable');
      const value=await response.json();
      if(ticket!==generation)return undefined;
      if(!valid(value))throw Error('Invalid access response');
      session={token:value.token,refreshToken:value.refreshToken,expiresAt:value.expiresAt,refreshExpiresAt:value.refreshExpiresAt};
      schedule();return session.token;
    }catch{
      if(ticket===generation){clearAccess();notify();}
      return undefined;
    }finally{if(controller===abort)controller=undefined;}
  }
  function refresh(){
    if(inflight)return inflight;
    if(!session)return Promise.resolve(undefined);
    if(Date.parse(session.refreshExpiresAt)<=now()){clearAccess();notify();return Promise.resolve(undefined);}
    const promise=request('refresh',{refreshToken:session.refreshToken},generation);
    inflight=promise;void promise.finally(()=>{if(inflight===promise)inflight=undefined;});return promise;
  }
  return Object.freeze({endpoint,
    async connect(invitation){
      clearAccess();
      if(typeof invitation!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(invitation)){notify();return false;}
      return Boolean(await request('redeem',{invitation,gameId,buildSha},generation));
    },
    async getToken(){
      if(!session)return undefined;
      if(Date.parse(session.expiresAt)-now()>5*60000)return session.token;
      return refresh();
    },
    clearAccess,
    dispose:clearAccess,
  });
}
