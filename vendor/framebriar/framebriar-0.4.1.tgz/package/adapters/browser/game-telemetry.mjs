// Versioned game semantics over Framebriar's enrolled-only OTLP emitter.
// Only authored identifiers and bounded scalar facts enter this layer; never user text.
import {createTelemetry, pageSessionId} from './telemetry.mjs';

export const GAME_TELEMETRY_LIMITS = Object.freeze({eventsPerMinute:60, errorsPerMinute:6,
  sessionBytes:512*1024, requestsPerHour:60, summaryMs:60000, queueAgeMs:300000});
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ID=/^[A-Za-z0-9_.:+-]{1,64}$/;
const EVENTS=/^game\.(?:action|control|progression|level\.end|wave\.start|weapon\.(?:select|use)|unit\.(?:select|build|move|scrap))$/;
const KEYS=new Set(('action action.name action.type action.outcome action.accepted action.sequence outcome phase '+
  'unit.id unit.type unit.level entity.id entity.type tower.count tower.family tower.level weapon.id faction.id '+
  'wave wave.index tick simulation.tick simulation.seconds rules.version player.count player.slot selection.source '+
  'module.id moves hints solution.length practice ammo scales.remaining ore energy mined kills units lives leaks '+
  'aim.angle aim.power duration.ms value').split(' ').map(k=>'game.'+k));
function safeAttributes(input={}) {
  const out={};
  for(const [k,v] of Object.entries(input).slice(0,32)) {
    if(!KEYS.has(k)&&!/^game\.(?:resource|count)\.[a-z][a-z0-9_]{0,24}$/.test(k))continue;
    if(typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<=1e12)out[k]=v;
    else if(typeof v==='boolean')out[k]=v;
    else if(KEYS.has(k)&&typeof v==='string'&&ID.test(v))out[k]=v;
    if(Object.keys(out).length===16)break;
  }
  return out;
}
const contextAttributes=({levelId,scenarioId,difficulty,seed,mode}={})=>Object.fromEntries(
  Object.entries({'game.level.id':levelId,'game.scenario.id':scenarioId,'game.difficulty':difficulty,
    'game.seed':seed,'game.mode':mode}).filter(([,v])=>typeof v==='number'&&Number.isFinite(v)||typeof v==='string'&&ID.test(v)));

export function createGameTelemetry({access,gameId,buildSha=null,appVersion,platform='web',
  storage,sessionId=pageSessionId(),now=()=>Date.now(),uuid=()=>crypto.randomUUID(),
  fetchImpl=(...args)=>fetch(...args),window=globalThis.window,document=globalThis.document,...sdkOptions}={}) {
  // Storage access itself can throw in restricted/opaque contexts.
  if(storage===undefined)try{storage=globalThis.localStorage;}catch{}
  const key=`framebriar.game.${gameId}.`,read=k=>{try{return storage?.getItem(key+k);}catch{return null;}},
    write=(k,v)=>{try{storage?.setItem(key+k,v);}catch{}};
  let selected=read('enabled')!=='false',disposed=false,installId,runId=uuid(),runContext={},runSpan,
    sessionStarted=false,runStarted=false,runEnded=false,closing=false,runAt=now(),minuteAt=now(),events=0,errors=0,
    sessionBytes=0,requestAt=now(),requests=0,dropped=0,perfAt=now(),lastSnapshot=-Infinity;
  const listeners=new Set(),performanceSamples=new Map();
  const allowed=()=>{try{const s=access.status();return selected&&!disposed&&s.enrolled===true&&s.notice==null&&
    !['disconnected','unsupported-origin','disconnecting','connecting'].includes(s.state);}catch{return false;}};
  const gated={endpoint:access.endpoint,status:()=>selected&&!disposed?access.status():{...access.status(),state:'telemetry-disabled'},
    getToken:async()=>allowed()?access.getToken():undefined,subscribe:fn=>{listeners.add(fn);return()=>listeners.delete(fn);}};
  const publish=()=>{for(const fn of listeners)fn(gated.status());};
  const transport=async(url,init)=>{
    if(!allowed())return new Response(null,{status:403});
    const size=new TextEncoder().encode(init.body).length,t=now();
    if(t-requestAt>=3600000){requestAt=t;requests=0;}
    if(sessionBytes+size>GAME_TELEMETRY_LIMITS.sessionBytes)return new Response(null,{status:403});
    if(requests>=GAME_TELEMETRY_LIMITS.requestsPerHour)return new Response(null,{status:429,headers:{'retry-after':String(Math.ceil((requestAt+3600000-t)/1000))}});
    sessionBytes+=size;requests++;
    return fetchImpl(url,init);
  };
  const raw=createTelemetry({...sdkOptions,access:gated,gameId,buildSha,sessionId,now,fetchImpl:transport,
    maxQueueAgeMs:GAME_TELEMETRY_LIMITS.queueAgeMs,window:null,document,
    captureErrors:false,captureConsole:false,frameTime:false});
  const common=()=>({'game.telemetry.schema_version':1,'game.id':gameId,'game.install.id':installId,
    'game.run.id':runId,'game.platform':ID.test(platform)?platform:'unknown',
    ...(appVersion&&/^[A-Za-z0-9._+-]{1,40}$/.test(appVersion)?{'game.version':appVersion}:{}),...runContext});
  function budget(kind='event'){
    if(now()-minuteAt>=60000){minuteAt=now();events=0;errors=0;}
    if(events>=GAME_TELEMETRY_LIMITS.eventsPerMinute||kind==='error'&&errors>=GAME_TELEMETRY_LIMITS.errorsPerMinute){dropped++;return false;}
    events++;if(kind==='error')errors++;return true;
  }
  const emit=(name,attrs={},severity='info',parent=runSpan?.context)=>{if(budget(severity==='error'?'error':'event'))raw.log(severity,name,{...common(),...attrs},{parent});};
  function ensure() {
    if(!allowed()||!raw.enabled)return false;
    if(!installId){const stored=read('install');installId=UUID.test(stored??'')?stored:uuid();if(!stored||stored!==installId)write('install',installId);}
    if(!sessionStarted){sessionStarted=true;emit('game.session.start');}
    if(!runStarted&&!runEnded){
      runStarted=true;
      // Sampling drops records, never correlation: a bounded-out run still gets random trace context.
      runSpan=budget()?raw.span('game.run',common(),{parent:null}):{
        context:{traceId:uuid().replaceAll('-',''),spanId:uuid().replaceAll('-','').slice(0,16)},setAttribute(){},end(){}};
      emit('game.run.start');
    }
    return true;
  }
  function clearLocal(){runSpan=undefined;runStarted=false;sessionStarted=false;performanceSamples.clear();perfAt=now();}
  const unsubscribe=access.subscribe?.(()=>{publish();if(!allowed())clearLocal();else ensure();});
  function take(kind='event'){
    if(closing||!ensure())return false;
    return true;
  }
  function performanceSummary(){
    if(!performanceSamples.size)return;
    if(take())for(const [kind,s] of performanceSamples)emit('game.performance.summary',{
      'game.performance.kind':kind,'game.performance.count':s.count,'game.performance.mean_ms':s.sum/s.count,
      'game.performance.max_ms':s.max,'game.performance.over_50ms':s.slow,'game.performance.window_ms':Math.max(0,now()-perfAt)});
    performanceSamples.clear();perfAt=now();
  }
  const api={sessionId,
    // Same interface expected by createDurableFeedback; the SDK still owns excerpts/commit timing.
    telemetry:Object.freeze({sessionId,get enabled(){return allowed()&&raw.enabled;},
      activeContext:()=>{ensure();return runSpan?.context;},
      feedbackSubmitted:options=>{if(!ensure())return Promise.resolve(false);return raw.feedbackSubmitted(options);},
      flush:options=>raw.flush(options),stats:()=>raw.stats()}),
    startRun(context={}){api.endRun('replaced');runId=uuid();runAt=now();runContext=contextAttributes(context);runStarted=false;runEnded=false;ensure();return runId;},
    endRun(outcome='abandoned',attrs={}){if(!runStarted)return;performanceSummary();if(ensure()){
      emit('game.run.end',{'game.outcome':ID.test(outcome)?outcome:'unknown','game.duration.ms':Math.max(0,now()-runAt),...safeAttributes(attrs)});
      runSpan?.setAttribute('game.outcome',ID.test(outcome)?outcome:'unknown');runSpan?.end();}
      runStarted=false;runEnded=true;},
    event(name,attrs={}){if(EVENTS.test(name)&&take())emit(name,safeAttributes(attrs));},
    snapshot(attrs={}){if(now()-lastSnapshot<60000||!take())return;lastSnapshot=now();emit('game.balance.snapshot',safeAttributes(attrs));},
    performance(kind,ms){if(!allowed()||!['frame','simulation','pathfinding','loading','snapshot'].includes(kind)||!Number.isFinite(ms)||ms<0||ms>600000)return;
      const s=performanceSamples.get(kind)??{count:0,sum:0,max:0,slow:0};s.count++;s.sum+=ms;s.max=Math.max(s.max,ms);if(ms>50)s.slow++;performanceSamples.set(kind,s);
      if(now()-perfAt>=60000)performanceSummary();},
    error(code){if(['runtime_error','unhandled_rejection','load_failed','simulation_failed','pathfinding_failed'].includes(code)&&take('error'))emit('game.error',{'error.type':code},'error');},
    feedbackContext(){ensure();return {sessionId,...(runSpan?.context??{}),
      ...(appVersion&&/^[A-Za-z0-9._+-]{1,40}$/.test(appVersion)?{appVersion}:{})};},
    setEnabled(value){selected=value===true;write('enabled',String(selected));publish();clearLocal();if(selected)ensure();},
    isEnabled:()=>selected,
    stats:()=>({...raw.stats(),attemptedBytes:sessionBytes,rateDropped:dropped}),
    dispose(){if(disposed||closing)return;api.endRun('closed');if(ensure())emit('game.session.end');closing=true;
      unsubscribe?.();window?.removeEventListener?.('error',onError);window?.removeEventListener?.('unhandledrejection',onRejection);window?.removeEventListener?.('pagehide',onHide);
      // Nonblocking best effort; the SDK bounds the request and never persists telemetry.
      const flushed=raw.flush();return flushed.finally(()=>{disposed=true;raw.dispose();clearLocal();});},
  };
  const onError=()=>api.error('runtime_error'),onRejection=()=>api.error('unhandled_rejection'),
    onHide=event=>{if(!event?.persisted){api.endRun('pagehide');if(ensure())emit('game.session.end');}void raw.flush({keepalive:true});};
  window?.addEventListener?.('error',onError);window?.addEventListener?.('unhandledrejection',onRejection);window?.addEventListener?.('pagehide',onHide);
  ensure();
  return Object.freeze(api);
}
