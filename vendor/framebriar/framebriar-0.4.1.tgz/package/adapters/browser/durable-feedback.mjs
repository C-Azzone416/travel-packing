import {DAY,LIMITS,normalizeReport} from '../../src/protocol.mjs';
import {migrateLegacyOutbox} from './migration.mjs';
import {OfflineQueue} from './queue.mjs';
import {sendPreparedFeedback} from './submit-feedback.mjs';

const digest=async blob=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');
const cancelled=()=>new DOMException('Local save cancelled','AbortError');
const terminal=new Set(['conflict','invalid-input','invalid-endpoint','invalid-media','permanent']);
// The host must supply SILENT access lookup/refresh, never a credential prompt/redemption.
// start() on page mount resumes durable work. stop() aborts delivery but never purges it.
export function createDurableFeedback({gameId,buildSha=null,endpoint,getToken,
  queue,indexedDB=globalThis.indexedDB,legacyBuildShas,now=()=>Date.now(),setTimer=setTimeout,clearTimer=clearTimeout,random=Math.random,
  onChange=()=>{},events=globalThis.window,isOnline=()=>globalThis.navigator?.onLine!==false,
  send=sendPreparedFeedback,onReceipt=()=>{},telemetry}){
  const url=new URL(endpoint);
  if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||
    !/^[a-z0-9-]{1,60}$/.test(gameId)||(buildSha!==null&&!/^[a-f0-9]{7,40}$/.test(buildSha))||typeof getToken!=='function')throw Error('Invalid durable feedback configuration');
  const base=url.href.replace(/\/$/,'');
  // Stable game/service scope. Each immutable report retains its original build provenance.
  const scope=`outbox-v2-${encodeURIComponent(base)}-${gameId}`;
  const storage=queue??new OfflineQueue(scope,{now,indexedDB});
  let running=false,timer,inflight,controller,migrating,migrationAbort,clearing=false,generation=0,migration={state:'not-checked'};
  const matches=r=>r?.gameId===gameId;
  const safeReceipt=ack=>{try{onReceipt(ack);}catch{/* Host callbacks cannot alter delivery. */}};
  async function schedule(){
    clearTimer(timer);timer=undefined;if(!running)return;
    try{
      const rows=await storage.all();await changed();if(!running||!rows.length)return;
      const retryable=rows.filter(x=>x.code!=='permanent');if(!retryable.length)return;
      const at=Math.min(...retryable.map(x=>x.nextAttemptAt||0));
      // Offline scheduling never deletes unsent feedback.
      timer=setTimer(()=>{void wake();},Math.max(isOnline()?1000:60000,at-now()));
    }catch{if(running)timer=setTimer(()=>{void wake();},60000);}
  }
  async function drain(ticket){
    if(!isOnline())return;
    const rows=await storage.all();
    for(const item of rows){
      if(!running||ticket!==generation)return;
      if(!matches(item.report)){
        await storage.defer(item.report.id,{attempts:item.attempts||0,code:'permanent',nextAttemptAt:0});
        continue; // A scoped store must never authorize another game.
      }
      if(item.code==='permanent'||(item.nextAttemptAt||0)>now())continue;
      const abort=new AbortController();controller=abort;
      try{
        const ack=await send({report:item.report,media:item.blob,endpoint:base,getToken,signal:abort.signal});
        if(!running||ticket!==generation)return;
        // Defense in depth if a host injects a transport for tests/integration.
        if(ack?.id!==item.report.id||ack.gameId!==gameId||!['ready','processed'].includes(ack.status))throw Object.assign(Error(),{code:'invalid-ack'});
        await storage.remove(item.report.id);safeReceipt(Object.freeze({id:ack.id,gameId,status:ack.status}));
      }catch(e){
        if(!running||ticket!==generation)return;
        const attempts=Math.min(32,(item.attempts||0)+1),code=typeof e?.code==='string'?e.code:'network';
        const backoff=Math.min(300000,2000*2**Math.min(attempts,8))+Math.floor(random()*1000);
        // Access may refresh/reconnect later; never dispose its family or mint new access here.
        const delay=code==='access-required'?300000:Math.max(backoff,e?.retryAfterMs||0,code==='quota'?60000:0);
        await storage.defer(item.report.id,{attempts,code:terminal.has(code)?'permanent':
          ['access-required','quota','network','invalid-ack','unavailable'].includes(code)?code:'network',
          nextAttemptAt:terminal.has(code)?0:now()+Math.min(delay,DAY)});
      }finally{if(controller===abort)controller=undefined;}
    }
  }
  function wake(){
    clearTimer(timer);timer=undefined;if(!running)return Promise.resolve();
    if(inflight)return inflight;
    const ticket=generation;
    const work=drain(ticket).catch(()=>{/* Persistence failure retains work; never claim delivery. */});
    inflight=work.finally(async()=>{if(inflight===result)inflight=undefined;await schedule();});
    const result=inflight;return result;
  }
  const online=()=>{void wake();};
  let view=Object.freeze({items:0,bytes:0,maxItems:LIMITS.queueItems,maxBytes:LIMITS.queueBytes,retention:'until-delivered-or-cleared',state:'checking'});
  const listeners=new Set([onChange]);
  async function changed(){try{const rows=await storage.all();view=Object.freeze({items:rows.length,bytes:rows.reduce((n,x)=>n+(x.blob?.size??0),0),maxItems:LIMITS.queueItems,maxBytes:LIMITS.queueBytes,retention:'until-delivered-or-cleared',blocked:rows.filter(x=>x.code==='permanent').length,state:'available',migration});}catch{view=Object.freeze({...view,state:'storage-unavailable'});}for(const fn of listeners)try{fn(view);}catch{}return view;}
  function stop(){running=false;generation++;clearTimer(timer);timer=undefined;events?.removeEventListener('online',online);controller?.abort();controller=undefined;migrationAbort?.abort();}
  return Object.freeze({
    status:()=>view,subscribe(fn){listeners.add(fn);fn(view);return()=>listeners.delete(fn);},
    async clear(){stop();clearing=true;try{await migrating?.catch(()=>{});await inflight;await storage.clear();return await changed();}finally{clearing=false;}},
    storage,
    // includeDiagnostics is the review screen's "Include recent app diagnostics" (default on).
    async enqueue({report,media,signal,includeDiagnostics=true}){
      if(clearing)throw Object.assign(Error('Local storage is being cleared'),{code:'storage-unavailable'});
      if(signal?.aborted)throw cancelled();
      const frozen=normalizeReport(structuredClone(report));
      if(!matches(frozen)||(frozen.media===null?media!==null:!(media instanceof Blob)||media.type!=='image/png'||media.size!==frozen.media.bytes||media.size>LIMITS.media))throw Error('Invalid reviewed feedback');
      if(frozen.media!==null&&frozen.media.sha256!==await digest(media))throw Error('Reviewed feedback hash mismatch');
      if(signal?.aborted)throw cancelled();
      try{await storage.add({report:frozen,blob:media},{signal});}catch(error){void changed();throw error;}
      void changed();
      // After the local commit: telemetry marker, consented excerpt, immediate flush.
      try{void telemetry?.feedbackSubmitted?.({reportId:frozen.id,traceId:frozen.traceId,spanId:frozen.spanId,includeDiagnostics})?.catch?.(()=>{});}catch{/* telemetry never affects feedback */}
      // Cancellation after IDB commit cannot discard accepted work or abort its delivery.
      if(running)void wake();
      return Object.freeze({id:frozen.id,gameId,status:'saved-local',sent:false});
    },
    async start(){
      if(clearing)return;if(!running){running=true;generation++;events?.addEventListener('online',online);}const ticket=generation;
      if(!queue){
        if(!migrating){const abort=new AbortController();migrationAbort=abort;
          migrating=migrateLegacyOutbox({endpoint:base,gameId,queue:storage,indexedDB,buildShas:legacyBuildShas,signal:abort.signal})
            .then(value=>{migration=value;},()=>{migration={state:'unavailable',sourcePreserved:true};})
            .finally(()=>{migrating=undefined;if(migrationAbort===abort)migrationAbort=undefined;});}
        await migrating;
      }
      if(!running||ticket!==generation)return;return wake();
    },
    // Call after successful access connection; respects persisted retry deadlines.
    resume:wake,
    stop,
  });
}
