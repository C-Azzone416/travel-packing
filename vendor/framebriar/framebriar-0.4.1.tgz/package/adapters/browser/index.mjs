import {LIMITS,DAY,redact,normalizeReport} from '../../src/protocol.mjs';
import {OfflineQueue} from './queue.mjs';
const digest=async blob=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer()))).map(b=>b.toString(16).padStart(2,'0')).join('');
const png=canvas=>new Promise((resolve,reject)=>{try{canvas.toBlob(b=>b?resolve(b):reject(Error('Canvas capture failed')),'image/png');}catch(e){reject(e);}});
export function createBrowserAdapter({enabled=false,canvas,context,renderForCapture=()=>{},endpoint,getToken,onStatus=()=>{}}) {
  if(!enabled)return {disabled:true,destroy(){},breadcrumb(){}};
  if(!(canvas instanceof HTMLCanvasElement))throw Error('Explicit game canvas required');
  const url=new URL(endpoint);if(url.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(url.hostname))throw Error('HTTPS intake required');
  const gameId=context().gameId;const queue=new OfflineQueue(gameId);const crumbs=[];
  let sending=false,disposed=false,retryTimer,attempts=0,activeRecorder;
  const status=message=>onStatus(message);
  async function request(path,options={}){
    const token=await getToken();if(!token)throw Object.assign(Error('Enter tester access token to send queued reports'),{status:401});
    const response=await fetch(`${endpoint.replace(/\/$/,'')}/v1/reports${path}`,{...options,headers:{...options.headers,authorization:`Bearer ${token}`},signal:AbortSignal.timeout(30000)});
    if(!response.ok){let body;try{body=await response.json();}catch{}throw Object.assign(Error(body?.error||`Intake ${response.status}`),{status:response.status});}
    return response.json();
  }
  async function flush(){
    if(sending||disposed)return;sending=true;clearTimeout(retryTimer);
    try{
      // Re-read after each batch: another Send may enqueue while HTTP is in flight.
      while(!disposed){
      const rows=await queue.all();
      if(!rows.length)return;
      for(const item of rows){
        if(disposed)return;
        try {
          const prepared=await request('',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(item.report)});
          const invalid=()=>Object.assign(Error('Invalid intake acknowledgement; capture retained'),{status:502});
          if(prepared?.id!==item.report.id)throw invalid();
          let accepted=prepared;
          if(prepared.status==='pending'){
            if(typeof prepared.ticket!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(prepared.ticket))throw invalid();
            accepted=await request(`/${item.report.id}/media`,{method:'PUT',headers:{'content-type':item.report.media.type,'x-upload-ticket':prepared.ticket},body:item.blob});
          }
          if(accepted?.id!==item.report.id||!['ready','processed'].includes(accepted.status))throw invalid();
          await queue.remove(item.report.id);attempts=0;status(`Sent ${item.report.id} → ${item.report.gameId}`);
        } catch(e){
          status(`Saved locally (${rows.length} queued): ${e.message}`);
          if(!e.status||e.status>=500||e.status===429){if(attempts++<8)retryTimer=setTimeout(flush,Math.min(300000,2000*2**attempts)+Math.random()*1000);}
          // Authentication and validation errors remain visible for manual retry/discard.
          return;
        }
      }
      }
    } finally {sending=false;}
  }
  const online=()=>{attempts=0;void flush().catch(e=>status(e.message));};window.addEventListener('online',online);
  return {
    snapshotContext(){return {...context(),capturedAt:new Date().toISOString(),breadcrumbs:structuredClone(crumbs)};},
    breadcrumb(kind,code,value){
      if(!['error','event','performance'].includes(kind))return;
      // Caller provides approved event codes and numbers, never a console/object dump.
      crumbs.push({kind,code:redact(code,100),atMs:Math.round(performance.now()),...(Number.isFinite(value)?{value}:{})});
      if(crumbs.length>LIMITS.breadcrumbs)crumbs.shift();
    },
    async screenshot(){await renderForCapture();const frozen=document.createElement('canvas');frozen.width=canvas.width;frozen.height=canvas.height;frozen.getContext('2d').drawImage(canvas,0,0);return frozen;},
    async video(seconds=5){
      if(activeRecorder)throw Error('Already recording');
      if(!canvas.captureStream||!globalThis.MediaRecorder)throw Error('Video unavailable; use screenshot');
      const type=['video/webm;codecs=vp8','video/webm','video/mp4'].find(t=>MediaRecorder.isTypeSupported(t));
      if(!type)throw Error('No supported video codec; use screenshot');
      const stream=canvas.captureStream(20);const chunks=[];let size=0;
      status('Recording game canvas only — no microphone or desktop');
      return new Promise((resolve,reject)=>{
        let timer;const recorder=new MediaRecorder(stream,{mimeType:type,videoBitsPerSecond:1500000});activeRecorder=recorder;
        const cleanup=()=>{clearTimeout(timer);stream.getTracks().forEach(t=>t.stop());activeRecorder=null;};
        recorder.ondataavailable=e=>{chunks.push(e.data);size+=e.data.size;if(size>LIMITS.media&&recorder.state==='recording')recorder.stop();};
        recorder.onerror=()=>{cleanup();reject(Error('Recording failed'));};
        recorder.onstop=()=>{cleanup();const blob=new Blob(chunks,{type:type.split(';')[0]});if(blob.size>LIMITS.media)reject(Error('Clip exceeds 8 MiB; capture a shorter clip'));else resolve(blob);};
        try{recorder.start(250);timer=setTimeout(()=>{if(recorder.state==='recording')recorder.stop();},Math.min(10,Math.max(1,seconds))*1000);}catch(e){cleanup();reject(e);}
      });
    },
    async send(blob,notes,extra={}){
      if(disposed)throw Error('Adapter disposed');
      const snapshot=structuredClone(extra.captureContext||context());
      if(snapshot.gameId!==gameId)throw Error('Game scope changed; create a separate adapter for that game');
      const report=normalizeReport({...snapshot,v:1,id:crypto.randomUUID(),capturedAt:snapshot.capturedAt||new Date().toISOString(),notes,breadcrumbs:snapshot.breadcrumbs||[...crumbs],
        ...(extra.callCorrelationId?{callCorrelationId:extra.callCorrelationId}:{}),media:{type:blob.type,bytes:blob.size,sha256:await digest(blob)}});
      // Persistence begins only when the tester explicitly presses Send.
      await queue.add({report,blob,queuedAt:Date.now()});status('Queued locally; sending…');await flush();return report.id;
    },flush,queue,
    cancelRecording(){if(activeRecorder?.state==='recording')activeRecorder.stop();},
    destroy(){disposed=true;clearTimeout(retryTimer);window.removeEventListener('online',online);if(activeRecorder?.state==='recording')activeRecorder.stop();crumbs.length=0;}
  };
}
export function mountCaptureButton(options) {
  if(!options.enabled)return {disabled:true,destroy(){},breadcrumb(){}};
  const host=document.createElement('div');const root=host.attachShadow({mode:'open'});let recognition,previewUrl,previewCanvas,clip;
  let capturedContext,previewEpoch=0;
  const adapter=createBrowserAdapter({...options,context:()=>capturedContext||options.context(),onStatus:message=>{status.textContent=message;options.onStatus?.(message);}});
  if(adapter.disabled)return adapter;
  root.innerHTML=`<style>:host{position:fixed;right:16px;bottom:16px;z-index:2147483647;font:14px system-ui;color:#eef4ff}button,textarea,input{font:inherit}button{padding:9px;margin:4px;border:1px solid #647997;border-radius:7px;cursor:pointer}section{background:#142035;border:1px solid #617899;border-radius:12px;padding:14px;width:min(540px,88vw);max-height:82vh;overflow:auto}textarea{width:96%;height:70px}canvas,video{max-width:100%;max-height:38vh;touch-action:none}p{font-size:12px}pre{white-space:pre-wrap;font-size:11px;max-height:140px;overflow:auto}</style>
    <button id="open">Capture feedback</button><section hidden><strong>Framebriar · debug capture</strong><p>Only the selected game canvas is captured. Review for private content before sending. Server media is scheduled to expire after 7 days; cleanup may run later. Send stores a local copy until delivered or explicitly cleared, within the 10-report / 32 MiB limit. Browser storage can be lost.</p><button id="shot">Screenshot</button><button id="video">Record 5 seconds</button><div id="preview"></div><p id="markup">Draw on a screenshot to mark the problem. Video clips support notes.</p><label>Notes<textarea maxlength="2000"></textarea></label><p>Optional dictation may send audio to your browser’s speech service. It requires microphone permission; Framebriar receives only the resulting text.</p><button id="dictate">Start dictation (consent)</button><button id="stop">Stop dictation</button><details><summary>Report context and breadcrumbs</summary><pre></pre></details><button id="send" disabled>Send reviewed capture</button><button id="close">Close / discard preview</button><p role="status"></p></section>`;
  const q=s=>root.querySelector(s),status=q('[role=status]'),panel=q('section'),preview=q('#preview'),notes=q('textarea');
  const run=fn=>async()=>{try{await fn();}catch(e){status.textContent=e.message;}};
  const reset=()=>{previewEpoch++;if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=null;clip=null;previewCanvas=null;capturedContext=null;preview.replaceChildren();q('#send').disabled=true;};
  const captureContext=()=>{capturedContext=adapter.snapshotContext();q('pre').textContent=JSON.stringify(capturedContext,null,2);};
  q('#open').onclick=()=>{panel.hidden=!panel.hidden;};
  q('#shot').onclick=run(async()=>{reset();captureContext();const epoch=previewEpoch;const image=await adapter.screenshot();if(epoch!==previewEpoch)return;previewCanvas=image;preview.append(previewCanvas);let drawing=false;const ctx=previewCanvas.getContext('2d');ctx.strokeStyle='#ff3159';ctx.lineWidth=Math.max(3,previewCanvas.width/220);ctx.lineCap='round';
    const point=e=>{const r=previewCanvas.getBoundingClientRect();return [(e.clientX-r.left)*previewCanvas.width/r.width,(e.clientY-r.top)*previewCanvas.height/r.height];};
    previewCanvas.onpointerdown=e=>{drawing=true;previewCanvas.setPointerCapture(e.pointerId);ctx.beginPath();ctx.moveTo(...point(e));};
    previewCanvas.onpointermove=e=>{if(drawing){ctx.lineTo(...point(e));ctx.stroke();}};
    previewCanvas.onpointerup=previewCanvas.onpointercancel=()=>drawing=false;q('#send').disabled=false;status.textContent='Preview ready; markup is included in the image.';
  });
  q('#video').onclick=run(async()=>{reset();captureContext();const epoch=previewEpoch;q('#video').disabled=q('#shot').disabled=true;try{const recording=await adapter.video();if(epoch!==previewEpoch)return;clip=recording;previewUrl=URL.createObjectURL(clip);const v=document.createElement('video');v.src=previewUrl;v.controls=true;preview.append(v);q('#send').disabled=false;status.textContent='Clip ready to review';}finally{q('#video').disabled=q('#shot').disabled=false;}});
  const Speech=globalThis.SpeechRecognition||globalThis.webkitSpeechRecognition;q('#dictate').disabled=!Speech;
  q('#dictate').onclick=run(async()=>{recognition?.abort();recognition=new Speech();recognition.continuous=false;recognition.interimResults=false;recognition.onresult=e=>{notes.value=(notes.value+' '+e.results[0][0].transcript).trim().slice(0,LIMITS.notes);};recognition.onerror=e=>status.textContent=`Dictation: ${e.error}; typing is always available`;recognition.start();});
  q('#stop').onclick=()=>recognition?.stop();
  q('#send').onclick=run(async()=>{recognition?.stop();q('#send').disabled=true;const epoch=previewEpoch,captureContext=structuredClone(capturedContext),reviewedNotes=notes.value;try{await adapter.send(clip||await png(previewCanvas),reviewedNotes,{captureContext});if(epoch===previewEpoch){reset();notes.value='';}}catch(e){if(epoch===previewEpoch)q('#send').disabled=false;throw e;}});
  q('#close').onclick=()=>{recognition?.abort();adapter.cancelRecording();reset();panel.hidden=true;};document.body.append(host);
  const originalDestroy=adapter.destroy;adapter.destroy=()=>{recognition?.abort();reset();originalDestroy();host.remove();};return adapter;
}
export {createTelemetry} from './telemetry.mjs';
export {pageSessionId,setPageSessionId,correlationContext} from './session.mjs';
