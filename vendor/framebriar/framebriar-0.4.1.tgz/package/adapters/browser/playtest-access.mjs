import {FEEDBACK_ENDPOINT} from './feedback-runtime.mjs';
import {migrateLegacyEnrollment} from './migration.mjs';
import {createEnrollmentStore} from './enrollment-store.mjs';
const HOUR=3600000,MONTH=30*86400000;
const token=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{43}$/.test(x);
const fault=kind=>Object.assign(new Error('Playtest access unavailable'),{kind});
export function supportedPlaytestOrigin(origin){
  try{const u=new URL(origin);return u.origin===origin&&(u.protocol==='https:'||
    (u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)));}catch{return false;}
}
// Application-lifetime controller. stop/unmount is not Disconnect.
// Cold starts of a scaled-to-zero service can take well over 10 s, so allow 45 s per access call.
export const ACCESS_TIMEOUT_MS=45000;
export function createPlaytestAccess({accessTimeoutMs=ACCESS_TIMEOUT_MS,retryDelay=ms=>new Promise(r=>setTimeout(r,ms)),gameId,buildSha=null,endpoint=FEEDBACK_ENDPOINT,
  origin=globalThis.location?.origin,store,legacyBuildSha,indexedDB=globalThis.indexedDB,fetchImpl=fetch,now=()=>Date.now(),
  setTimer=setTimeout,clearTimer=clearTimeout,events=globalThis.window,onChange=()=>{}}){
  let lastAttempt; // {invitation, attemptId, at}: in memory only, reused when the user retries the same invite
  if(endpoint!==FEEDBACK_ENDPOINT||!/^[a-z0-9-]{1,60}$/.test(gameId)||(buildSha!==null&&!/^[a-f0-9]{7,40}$/.test(buildSha)))throw Error('Invalid playtest scope');
  const supported=supportedPlaytestOrigin(origin);
  const storage=supported?(store??createEnrollmentStore({endpoint,gameId,now,indexedDB})):null;
  let running=false,disposed=false,generation=0,revision=null,session,timer,controller,inflight,operation,failures=0;
  let notice=null,optedIn=false,legacySelection=false;
  let view=Object.freeze({state:supported?'disconnected':'unsupported-origin',connected:false,enrolled:false,canCapture:false,notice:null,expiresAt:null});
  const listeners=new Set([onChange]);
  const emit=(state,expiresAt=session?.refreshExpiresAt??null)=>{
    view=Object.freeze({state,connected:state==='connected',enrolled:optedIn,canCapture:optedIn,notice:notice?.state??null,expiresAt:expiresAt??notice?.expiresAt??null});
    for(const fn of listeners)try{fn(view);}catch{/* UI cannot change enrollment */}
    return view;
  };
  const halt=()=>{generation++;clearTimer(timer);timer=undefined;controller?.abort();controller=undefined;inflight=undefined;operation=undefined;session=undefined;};
  const current=ticket=>running&&!disposed&&ticket===generation;
  const valid=x=>x?.v===1&&x.gameId===gameId&&x.scopeVersion===2&&token(x.token)&&token(x.refreshToken)&&
    Date.parse(x.expiresAt)>now()&&Date.parse(x.expiresAt)<=now()+HOUR&&
    Date.parse(x.refreshExpiresAt)>=Date.parse(x.expiresAt)&&Date.parse(x.refreshExpiresAt)<=now()+MONTH;
  async function request(action,body,ticket){
    const abort=new AbortController();controller=abort;
    try{
      const response=await fetchImpl(`${endpoint}/v1/access/${action}`,{method:'POST',credentials:'omit',redirect:'error',cache:'no-store',
        headers:{'content-type':'application/json'},body:JSON.stringify({v:1,...body}),
        signal:AbortSignal.any([abort.signal,AbortSignal.timeout(accessTimeoutMs)])});
      if(!current(ticket))throw fault('stale');
      if(!response.ok){await response.body?.cancel();throw fault([401,403].includes(response.status)?'denied':'transient');}
      if(response.redirected||response.headers.get('content-type')?.split(';')[0]!=='application/json')throw fault('invalid');
      const reader=response.body?.getReader();if(!reader)throw fault('invalid');
      const chunks=[];let length=0;
      try{while(true){const {value,done}=await reader.read();if(done)break;length+=value.length;
        if(length>2048){await reader.cancel();throw fault('invalid');}chunks.push(value);
      }}finally{reader.releaseLock();}
      if(!current(ticket))throw fault('stale');
      const bytes=new Uint8Array(length);let offset=0;for(const x of chunks){bytes.set(x,offset);offset+=x.length;}
      return JSON.parse(new TextDecoder().decode(bytes));
    }catch(e){throw e?.kind?e:fault('transient');}
    finally{if(controller===abort)controller=undefined;}
  }
  function schedule(ms){clearTimer(timer);if(running)timer=setTimer(()=>{void refresh();},Math.max(1000,ms));}
  async function adoptStored(ticket){
    const saved=await storage.read();if(!current(ticket))return;
    revision=saved.revision;notice=saved.notice??null;optedIn=!!saved.session||!!notice&&notice.enrolled!==false;
    session=saved.session?{refreshToken:saved.session.refreshToken,refreshExpiresAt:saved.session.expiresAt}:undefined;
    emit(session?'checking':notice?.state??'disconnected',session?.refreshExpiresAt??null);
    if(session)schedule(1000);
  }
  async function forget(ticket,state){
    const expectedRevision=revision;
    const reason={state,expiresAt:session?.refreshExpiresAt??notice?.expiresAt??null,enrolled:optedIn};
    const next=await storage.reset({expectedRevision,notice:reason});
    if(!current(ticket))return;
    session=undefined;
    if(next===null){await adoptStored(ticket);return;}
    revision=next;notice=reason;optedIn=true;emit(state,null);
  }
  async function accept(value,ticket){
    if(!valid(value))throw fault('invalid');
    if(!current(ticket))return false;
    const saved=await storage.write({refreshToken:value.refreshToken,expiresAt:value.refreshExpiresAt},revision);
    if(!current(ticket))return false;
    if(!saved){session=undefined;await adoptStored(ticket);return false;}
    session={token:value.token,refreshToken:value.refreshToken,expiresAt:value.expiresAt,refreshExpiresAt:value.refreshExpiresAt};
    notice=null;optedIn=true;failures=0;emit('connected');
    if(!current(ticket))return false;
    const end=Date.parse(session.refreshExpiresAt),expiry=Date.parse(session.expiresAt);
    schedule((expiry>=end?end:expiry-4*60000)-now());
    return true;
  }
  async function restoreOrRefresh(ticket){
    try{
      if(!session){
        const saved=await storage.read();if(!current(ticket))return;
        revision=saved.revision;
        if(!saved.session){notice=saved.notice??null;optedIn=!!notice&&notice.enrolled!==false;emit(notice?.state??'disconnected',null);return;}
        optedIn=true;session={refreshToken:saved.session.refreshToken,refreshExpiresAt:saved.session.expiresAt};
      }
      if(Date.parse(session.refreshExpiresAt)<=now()){await forget(ticket,'expired');return;}
      const value=await request('refresh',{refreshToken:session.refreshToken,scopeVersion:2},ticket);
      if(!current(ticket))return;
      // The issuer rotates only access, never the refresh credential or family deadline.
      // Concurrent tabs may persist replies in either order only under this invariant.
      if(value.refreshToken!==session.refreshToken||value.refreshExpiresAt!==session.refreshExpiresAt)throw fault('invalid');
      await accept(value,ticket);
    }catch(e){
      if(!current(ticket))return;
      if(e?.kind==='denied'){try{await forget(ticket,'access-required');}catch{session=undefined;emit('storage-unavailable',null);}return;}
      if(!e?.kind){session=undefined;emit('storage-unavailable',null);return;}
      // Offline/rate limit/server outage: retain enrollment, but never show Connected.
      if(session)delete session.token;
      emit('offline');schedule(Math.min(300000,5000*2**Math.min(failures++,6)));
    }
  }
  function refresh(){
    if(!running||disposed||!supported||operation)return Promise.resolve(view);
    if(inflight)return inflight;
    const ticket=generation,work=restoreOrRefresh(ticket);
    const result=work.finally(()=>{if(inflight===result)inflight=undefined;});inflight=result;return result;
  }
  const online=()=>{void refresh();};
  const unsubscribe=storage?.subscribe(changed=>{
    if(changed===revision||!running)return;
    halt();void refresh();
  });
  return Object.freeze({endpoint,
    status:()=>view,
    subscribe(fn){listeners.add(fn);fn(view);return()=>listeners.delete(fn);},
    async start(){
      if(disposed||!supported)return view;
      if(running){if(inflight)await inflight;return view;}
      running=true;events?.addEventListener('online',online);emit('checking',null);
      const ticket=generation;
      if(!store)try{const migration=await migrateLegacyEnrollment({endpoint,gameId,store:storage,indexedDB,buildSha:legacyBuildSha});if(!current(ticket))return view;if(migration.state==='selection-required'){legacySelection=true;notice={state:'migration-required',expiresAt:null};emit('migration-required');return view;}}catch{if(current(ticket))emit('storage-unavailable');return view;}
      await refresh();return view;
    },
    stop(){running=false;events?.removeEventListener('online',online);halt();emit(supported?(notice?.state??(optedIn?'stopped':'disconnected')):'unsupported-origin',null);},
    async connect(invitation){
      if(disposed||!supported||!token(invitation)||operation)return false;
      // Explicit redemption. Transient failures (timeouts, 5xx) are retried with the SAME attempt id,
      // which the service treats idempotently for 15 min, so a slow cold start cannot burn the invite.
      halt();legacySelection=false;running=true;events?.addEventListener('online',online);const ticket=generation;operation='connect';emit('connecting',null);
      try{
        const old=await storage.read();if(!current(ticket))return false;
        optedIn=!!old.session||!!old.notice&&old.notice.enrolled!==false;
        const next=await storage.reset({expectedRevision:old.revision,notice:{state:'connection-uncertain',enrolled:optedIn}});if(!current(ticket))return false;
        if(next===null)throw fault('stale');revision=next;
        if(!lastAttempt||lastAttempt.invitation!==invitation||now()-lastAttempt.at>14*60000)lastAttempt={invitation,attemptId:(()=>{const b=new Uint8Array(16);crypto.getRandomValues(b);return btoa(String.fromCharCode(...b)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');})(),at:now()};
        const attempt=lastAttempt;
        let value;
        for(let n=0;;n++){
          try{value=await request('redeem',{invitation,gameId,buildSha,scopeVersion:2,attemptId:attempt.attemptId},ticket);break;}
          catch(e){if(e?.kind!=='transient'||n>=2||!current(ticket))throw e;await retryDelay(n?5000:2000);if(!current(ticket))throw fault('stale');}
        }
        invitation=undefined;
        const accepted=await accept(value,ticket);
        // A successful response may already have spent the invite. Keep its identity
        // until validation and persistence succeed, without clearing a newer attempt.
        if(accepted&&current(ticket)&&lastAttempt===attempt)lastAttempt=undefined;
        return accepted;
      }catch(e){
        if(current(ticket)){session=undefined;notice={state:e?.kind==='denied'?'access-required':'connection-uncertain',expiresAt:null,enrolled:optedIn};try{const next=await storage.reset({expectedRevision:revision,notice});if(current(ticket)&&next!==null)revision=next;}catch{}if(current(ticket))emit(e?.kind?notice.state:'storage-unavailable',null);}
        return false;
      }finally{invitation=undefined;if(ticket===generation)operation=undefined;}
    },
    async getToken(){
      if(!running||disposed||operation||legacySelection)return undefined;
      // Cross-tab disconnect must hold even if BroadcastChannel is unavailable.
      const ticket=generation;
      try{
        const saved=await storage.read();if(!current(ticket)||operation)return undefined;
        if(saved.revision!==revision||saved.session?.refreshToken!==session?.refreshToken){
          session=undefined;revision=saved.revision;
        }
        if(!saved.session){notice=saved.notice??null;optedIn=!!notice&&notice.enrolled!==false;emit(notice?.state??'disconnected',null);return undefined;}
      }catch{if(current(ticket)){session=undefined;emit('storage-unavailable',null);}return undefined;}
      if(session?.token&&Date.parse(session.expiresAt)-now()>5*60000)return session.token;
      await refresh();return session?.token&&Date.parse(session.expiresAt)>now()?session.token:undefined;
    },
    async disconnect(){
      if(disposed||!supported)return {forgotten:false,revoked:false};
      lastAttempt=undefined;halt();legacySelection=false;running=true;const ticket=generation;operation='disconnect';emit('disconnecting',null);
      try{
        const old=await storage.read();if(!current(ticket))return {forgotten:false,revoked:false};
        const next=await storage.reset({expectedRevision:old.revision});
        if(!current(ticket)||next===null)return {forgotten:false,revoked:false};
        revision=next;notice=null;optedIn=false;emit('disconnected',null);
        if(!old.session)return {forgotten:true,revoked:null};
        try{const result=await request('disconnect',{refreshToken:old.session.refreshToken},ticket);
          return {forgotten:true,revoked:result?.v===1&&result.disconnected===true};
        }catch{return {forgotten:true,revoked:false};}
      }catch{if(current(ticket))emit('storage-unavailable',null);return {forgotten:false,revoked:false};}
      finally{if(ticket===generation)operation=undefined;}
    },
    dispose(){running=false;disposed=true;lastAttempt=undefined;events?.removeEventListener('online',online);halt();unsubscribe?.();storage?.close();listeners.clear();},
  });
}
