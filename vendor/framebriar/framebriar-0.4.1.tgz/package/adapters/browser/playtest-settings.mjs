// Small optional DOM adapter. The application owns the controller and its lifetime.
export function mountPlaytestSettings({root,access}){
  if(!root?.ownerDocument||!access?.subscribe)throw Error('Settings root and access controller required');
  const doc=root.ownerDocument,section=doc.createElement('section'),heading=doc.createElement('h3');
  heading.textContent='Feedback';
  const status=doc.createElement('p');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
  const form=doc.createElement('form'),label=doc.createElement('label'),input=doc.createElement('input');
  label.textContent='Invite code ';input.type='password';input.autocomplete='off';input.spellcheck=false;
  input.maxLength=43;input.setAttribute('aria-label','Feedback invite code');label.append(input);
  const connect=doc.createElement('button');connect.type='submit';connect.textContent='Connect';
  const disconnect=doc.createElement('button');disconnect.type='button';disconnect.textContent='Clear enrollment';
  form.append(label,connect,disconnect);section.append(heading,status,form);root.append(section);
  let mounted=true;
  const messages={disconnected:'Not connected',checking:'Checking connection…',connecting:'Connecting…',
    disconnecting:'Disconnecting…',offline:'Connection unavailable. Saved feedback stays on this device.',
    'migration-required':'Existing enrollment needs a choice. Enter a replacement code or clear enrollment.',
    stopped:'Feedback is enabled; delivery is stopped.',
    expired:'Feedback access expired. Enter a new invite code.',
    'access-required':'Feedback access is no longer valid. Enter a new invite code.',
    'storage-unavailable':'Could not remember access on this device. Check browser storage and try again.',
    'connection-uncertain':'Connection could not be confirmed. No automatic reconnect attempt was made.',
    'unsupported-origin':'Feedback access needs a supported secure browser origin or native adapter.'};
  const render=value=>{
    if(!mounted)return;
    status.textContent=value.connected?`Connected · expires ${new Date(value.expiresAt).toLocaleString()}`:messages[value.state]??'Not connected';
    const busy=['checking','connecting','disconnecting'].includes(value.state),unsupported=value.state==='unsupported-origin';
    input.disabled=connect.disabled=busy||unsupported;
    disconnect.disabled=unsupported||value.state==='disconnecting';
    if(value.connected)input.value='';
  };
  const unsubscribe=access.subscribe(render);
  const submit=event=>{
    event.preventDefault();if(connect.disabled)return;
    let invitation=input.value.trim();input.value='';
    if(!/^[A-Za-z0-9_-]{43}$/.test(invitation)){status.textContent='Enter the invite code exactly as provided.';return;}
    const work=access.connect(invitation);invitation=undefined;
    void Promise.resolve(work).catch(()=>{if(mounted)status.textContent='Connection unavailable.';});
  };
  const forget=()=>{input.value='';void access.disconnect().then(result=>{
    if(mounted&&access.status().state==='disconnected'&&result.forgotten&&result.revoked===false)
      status.textContent='Disconnected on this device. Server revocation could not be confirmed.';
  }).catch(()=>{if(mounted)status.textContent='Could not disconnect. Try again.';});};
  form.addEventListener('submit',submit);disconnect.addEventListener('click',forget);
  return ()=>{mounted=false;input.value='';unsubscribe();form.removeEventListener('submit',submit);disconnect.removeEventListener('click',forget);section.remove();};
}
