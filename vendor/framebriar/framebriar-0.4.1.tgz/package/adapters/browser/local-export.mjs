import {LIMITS, normalizeReport} from '../../src/protocol.mjs';
// The page run's session (see pageSessionId in telemetry.mjs), without importing it.
const SLOT = Symbol.for('framebriar.page-session');
function pageSessionId() {
  if (/^[A-Za-z0-9_-]{1,64}$/.test(globalThis[SLOT] ?? '')) return globalThis[SLOT];
  const b = new Uint8Array(12);
  do crypto.getRandomValues(b); while (b.every(x => x === 0));
  return globalThis[SLOT] = `s-${Array.from(b, x => x.toString(16).padStart(2, '0')).join('')}`;
}

// Call only after explicit review/Save. The host owns canvas capture and download UI.
// No endpoint, token, queue, network, storage, microphone or automatic download.
export async function prepareLocalFeedback({blob, captureContext, notes = ''}) {
  if (blob!==null&&(!(blob instanceof Blob) || blob.type !== 'image/png' ||
      blob.size === 0 || blob.size > LIMITS.media)) {
    throw Error('A reviewed PNG of at most 8 MiB is required');
  }
  if (!captureContext?.capturedAt) throw Error('Capture-time context is required');
  // Capture context may carry traceId/spanId/appVersion (see correlationContext); the
  // session defaults to this page run's, shared with telemetry. Seed may be null.
  const context = {sessionId: pageSessionId(), seed: null, ...structuredClone(captureContext)};
  const reviewedNotes = String(notes);
  const bytes = blob===null?null:await blob.arrayBuffer();
  const hash = bytes===null?null:Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)),
    byte => byte.toString(16).padStart(2, '0')).join('');
  const report = normalizeReport({...context, v: 1, id: crypto.randomUUID(),
    notes: reviewedNotes, breadcrumbs: context.breadcrumbs ?? [],
    media: blob===null?null:{type: blob.type, bytes: blob.size, sha256: hash}});
  const base = `${report.gameId}-${report.id}`;
  return {
    report,
    media: blob,
    metadata: new Blob([JSON.stringify(report, null, 2) + '\n'], {type: 'application/json'}),
    filenames: {media: blob===null?null:`${base}.png`, metadata: `${base}.json`}
  };
}
