// Headless browser capture lifecycle. No DOM, access, storage or transport.
export function createFeedbackController({enabled=false,capture,openReview,canCapture=()=>true,
  onError=()=>{},onActiveChange=()=>{}}={}) {
  if(!enabled)return Object.freeze({disabled:true,get active(){return false;},openFeedback(){return false;},destroy(){}});
  if(typeof capture!=='function'||typeof openReview!=='function'||typeof canCapture!=='function')
    throw Error('Capture, review and eligibility callbacks are required.');
  let current,destroyed=false;
  const notify=active=>{try{onActiveChange(active);}catch{/* Presentation cannot own lifecycle. */}};
  const error=()=>{try{onError(new Error('Feedback capture could not be opened.'));}catch{}};
  function openFeedback() {
    if(destroyed||current)return false;
    // Reserve before any app callback: eligibility/capture can synchronously reenter.
    const ticket={closed:false,snapshot:undefined};current=ticket;
    function close(){
      if(ticket.closed)return;ticket.closed=true;
      try{ticket.snapshot?.restore();}finally{
        if(current===ticket){current=undefined;notify(false);}
      }
    }
    ticket.close=close;
    try{
      if(!canCapture()||destroyed){close();return false;}
      ticket.snapshot=capture();
      if(!ticket.snapshot||typeof ticket.snapshot.then==='function'||typeof ticket.snapshot.restore!=='function')
        throw Error('Synchronous capture/restore required.');
      // destroy() may have run inside capture, before its restore closure was returned.
      if(destroyed){ticket.snapshot.restore();return false;}
      notify(true);
      if(destroyed||ticket.closed)return false;
      const result=openReview(ticket.snapshot,{close});
      if(result?.then)Promise.resolve(result).catch(()=>{
        if(current!==ticket||ticket.closed)return;
        try{close();}catch{/* Report only a fixed error. */}finally{error();}
      });
      return true;
    }catch{
      const ownsReview=current===ticket;
      try{close();}catch{/* Report only a fixed error. */}finally{if(ownsReview)error();}
      return false;
    }
  }
  return Object.freeze({get active(){return Boolean(current);},openFeedback,
    destroy(){if(destroyed)return;destroyed=true;try{current?.close();}catch{error();}}});
}
