// Explicit private-host entry only. No enrollment, logging, UI or secret persistence.
export function createInvitationEntry({gameId,buildSha,fetchImpl=fetch,now=()=>Date.now()}) {
  if(gameId!=='relay-frontier'||!/^[a-f0-9]{40}$/.test(buildSha))throw Error('Invalid private entry scope');
  let attempted=false;
  const error=code=>Object.assign(new Error('Private connection unavailable'),{code});
  const match=v=>v?.v===1&&v.gameId===gameId&&v.buildSha===buildSha;
  async function request(path,method,signal){
    if(signal?.aborted)throw error('aborted');
    const timeout=AbortSignal.timeout(10000),abort=signal?AbortSignal.any([signal,timeout]):timeout;
    const response=await fetchImpl(path,{method,credentials:'omit',cache:'no-store',redirect:'error',signal:abort,
      ...(method==='POST'?{headers:{'content-type':'application/json'},body:JSON.stringify({v:1,gameId,buildSha})}:{})});
    if(abort.aborted)throw error('aborted');
    if(!response.ok||response.redirected||response.headers.get('content-type')?.split(';')[0]!=='application/json')throw error('unavailable');
    const reader=response.body?.getReader();if(!reader)throw error('unavailable');
    let size=0,text='';const decoder=new TextDecoder();
    try{while(true){const {value,done}=await reader.read();
      if(abort.aborted){await reader.cancel();throw error('aborted');}
      if(done)break;size+=value.byteLength;if(size>1024){await reader.cancel();throw error('unavailable');}
      text+=decoder.decode(value,{stream:true});
    }}finally{reader.releaseLock();}
    if(abort.aborted)throw error('aborted');
    return JSON.parse(text+decoder.decode());
  }
  return Object.freeze({
    async available({signal}={}){try{const value=await request('/framebriar/connection','GET',signal);return match(value)&&value.available===true;}catch{return false;}},
    async requestInvitation({signal}={}){
      if(attempted)throw error('already-attempted');
      if(signal?.aborted)throw error('aborted');
      attempted=true;
      try{
        const value=await request('/framebriar/invitation','POST',signal);
        if(signal?.aborted)throw error('aborted');
        const expiry=Date.parse(value?.expiresAt);
        if(!match(value)||!/^[A-Za-z0-9_-]{43}$/.test(value.invitation||'')||!Number.isFinite(expiry)||expiry<=now()||expiry>now()+3600000)throw error('unavailable');
        return {invitation:value.invitation,expiresAt:value.expiresAt};
      }catch{throw error(signal?.aborted?'aborted':'uncertain');}
    },
  });
}
