# Framebriar for Node and Electron (main process)

This is the Framebriar feedback and telemetry SDK for Node 20+ and Electron main processes. It talks to the same API as the browser and Godot adapters:

- v2 enrollment at `{endpoint}/v1/access/*`
- report intake at `/v1/reports`
- telemetry at `/v1/telemetry`

Contracts: [general-feedback-v2.md](../../docs/general-feedback-v2.md), [telemetry.md](../../docs/telemetry.md), [correlation.md](../../docs/correlation.md).

- **Zero npm dependencies.** The SDK uses Node built-ins only (`fetch`, `crypto`, `fs`). Electron APIs are *injected* by the host, never imported, so the SDK runs (and is tested) under plain Node.
- **Main process only.** Requests from the main process carry no `Origin` header, so there's no CORS or origin registration. The renderer never sees tokens, the invitation or the outbox. It talks to the main process over IPC.
- **Files it needs:** `adapters/node/*.mjs`, `adapters/browser/telemetry.mjs` (pure helpers only: scrubbing, attributes, histograms) and `src/protocol.mjs`. Keep that relative layout when vendoring.

## Wiring the main process

```js
// main/framebriar.mjs
import {app, safeStorage, net, ipcMain, BrowserWindow} from 'electron';
import {join} from 'node:path';
import {createFramebriar} from './vendor/framebriar/adapters/node/index.mjs';

let fb;
export async function startFramebriar(win) {
  await app.whenReady();                     // Linux safeStorage backends load late
  fb = createFramebriar({
    safeStorage,                             // OS-backed encryption, no plaintext fallback
    dataDir: join(app.getPath('userData'), 'framebriar'),
    appId: 'clubhouse',                      // registry app id ([a-z0-9-]{1,60})
    appVersion: app.getVersion(),            // e.g. 0.42.0-beta.1
    buildSha: null,                          // or the 7–40 hex commit if you have one
    telemetry: 'excerpt-only',               // 'continuous' | 'excerpt-only' | 'off'
    capture: () => win.webContents.capturePage().then(image => image.toPNG()),
    isOnline: () => net.isOnline(),
    onAccessChange: view => win.webContents.send('framebriar:access', view),
    onOutboxChange: view => win.webContents.send('framebriar:outbox', view),
  });
  await fb.start();                          // restores enrollment silently, then resumes the outbox
  registerIpc();
  app.on('before-quit', () => { void fb.shutdown(); });
  return fb;
}
```

`createFramebriar` is a thin convenience. Use the individual factories (`createSecureStore`, `createAccess`, `createOutbox`, `createTelemetry`, `createFeedback`) when you need control. They take the same options.

### Secure storage

`createSecureStore({safeStorage, file, scope})` keeps one compare-and-swap record `{revision, session, notice}`:

- **Encryption:** the record is encrypted with `safeStorage.encryptString`. That means Keychain on macOS, DPAPI on Windows, and libsecret or kwallet on Linux.
- **Writes:** each write goes to a temp file, then fsync, rename and a directory fsync.
- **Concurrency:** writers are serialized across processes by an `O_EXCL` lockfile with stale-pid recovery.
- **What's stored:** only the 30-day refresh credential and its deadline. Invitations and one-hour upload tokens never touch disk.

There's no plaintext fallback. Every operation is refused when:

- `safeStorage.isEncryptionAvailable()` is false, or
- on Linux, `safeStorage.getSelectedStorageBackend()` is `basic_text` (Chromium's hardcoded key) or `unknown`. `unknown` means the app isn't ready yet.

When storage is refused, access reports `state: 'storage-unavailable'` and `canCapture: false`. Show this in your Feedback settings, for example: "Feedback needs your system keyring (GNOME Keyring or KWallet)." `fb.store.probe()` returns `{available, reason, backend}`.

If the OS key is reset, the record no longer decrypts. Connecting again (a new invitation) or Disconnect replaces the record. Nothing else touches it.

### Lifecycle

| Event | Call |
|---|---|
| App ready | `await fb.start()` |
| User enters an invitation | `await fb.access.connect(invitation)`, then clear the field immediately. It's never retried automatically. A lost reply leaves `notice: 'connection-uncertain'` until the user tries again. |
| User clicks Disconnect / Clear enrollment | `await fb.access.disconnect()` resolves to `{forgotten, revoked}`. Queued reports are **kept** and delivered after a later enrollment. |
| Clear unsent feedback (explicit only) | `await fb.outbox.clear()` |
| Quit | `await fb.shutdown()` does one bounded telemetry flush (≤ 2 s) and leaves the outbox on disk. |

`fb.access.status()` returns `{state, connected, enrolled, canCapture, notice, expiresAt}`:

- **Feedback button:** show it only when `canCapture === true`.
- **Notices:** show `notice` (`expired`, `access-required`, `connection-uncertain`) visibly outside Settings. It persists until a replacement enrollment or Disconnect clears it.
- **Expiry:** `expiresAt` is the 30-day family deadline.

## IPC for the renderer's Feedback button

The PNG is captured in the main process at the moment feedback opens, together with the active trace. Notes are added during review. The report is frozen in `prepare`, and `submit` commits it to disk before acknowledging.

```js
// main: registerIpc()
const drafts = new Map();
ipcMain.handle('framebriar:status', () => ({access: fb.access.status(), outbox: fb.outbox.status()}));
ipcMain.handle('framebriar:connect', (_e, invitation) => fb.access.connect(String(invitation)));
ipcMain.handle('framebriar:disconnect', () => fb.access.disconnect());
ipcMain.handle('framebriar:open', async () => {
  const shot = await fb.feedback.open();           // throws 'feedback-unavailable' if not eligible
  const draftId = crypto.randomUUID();
  drafts.set(draftId, shot);
  return {draftId, preview: shot.png && `data:image/png;base64,${shot.png.toString('base64')}`};
});
ipcMain.handle('framebriar:submit', async (_e, {draftId, notes, includeDiagnostics, scene}) => {
  const shot = drafts.get(draftId); drafts.delete(draftId);
  if (!shot) throw new Error('Feedback draft expired');
  const prepared = await fb.feedback.prepare({notes, context: {scene}, ...shot});
  return fb.feedback.submit(prepared, {includeDiagnostics: includeDiagnostics !== false});
  // -> {id, gameId, status: 'saved-local', sent: false, diagnostics}; delivery happens in the background
});
ipcMain.handle('framebriar:cancel', (_e, draftId) => drafts.delete(draftId));
```

```js
// preload
contextBridge.exposeInMainWorld('framebriar', {
  status: () => ipcRenderer.invoke('framebriar:status'),
  connect: invitation => ipcRenderer.invoke('framebriar:connect', invitation),
  disconnect: () => ipcRenderer.invoke('framebriar:disconnect'),
  open: () => ipcRenderer.invoke('framebriar:open'),
  submit: draft => ipcRenderer.invoke('framebriar:submit', draft),
  cancel: draftId => ipcRenderer.invoke('framebriar:cancel', draftId),
  onAccess: fn => ipcRenderer.on('framebriar:access', (_e, v) => fn(v)),
  onOutbox: fn => ipcRenderer.on('framebriar:outbox', (_e, v) => fn(v)),
});
```

- **Validating IPC:** validate IPC arguments the way the host already does (Clubhouse uses `withValidatedArgs`). Treat `notes` and `scene` as untrusted text. The SDK redacts URLs, emails, tokens and home-directory paths from notes, and bounds every field.
- **Without a screenshot:** for text-only feedback, call `prepare({notes, png: null})`. The report is ready after `POST /v1/reports` alone.
- **Breadcrumbs:** `context.breadcrumbs` takes up to 40 entries of `{kind: 'error' | 'performance' | 'event', atMs, code, value?}`. Use approved codes, never user text.

## Consent text

Settings, next to the invitation field. Say this for `telemetry: 'continuous'`:

> Connecting also shares performance and diagnostic data with the developer.

For `telemetry: 'excerpt-only'`, nothing is shared continuously, so say:

> Connecting lets you send feedback and screenshots to the developer.

Review screen, as a checkbox that is **on by default**. Pass its value as `includeDiagnostics`:

> ☑ Include recent app diagnostics (the last 5 minutes of this app's Framebriar logs and traces)

## Telemetry

`fb.telemetry` has the same API as the browser SDK: `span`, `withSpan`, `log`, `exception`, `counter`, `gauge`, `histogram`, `activeContext`, `flush`. It only records while the user is enrolled. Every call is a no-op otherwise, and Disconnect drops the buffer immediately.

- **Memory only.** Nothing is written to disk. Batches flush every 60 s, at 200 items or at 64 KiB.
- **Approved attributes.** Attributes must be approved codes and numbers. Never send user-entered text, file paths, prompts, repository names, emails, URLs with queries or tokens. The SDK scrubs lightly, and the gateway redacts again, but neither is the plan.
- **Error capture.** `captureErrors: true` records `uncaughtExceptionMonitor` events as exception logs without changing Node's crash behaviour.
- **One session ID.** One session ID per app run (`fb.telemetry.sessionId`) is shared by reports and telemetry (`framebriar.session.id`).

### On submit (docs/correlation.md)

After the report commits locally, `submit` calls `telemetry.feedbackSubmitted`. That call does three things:

1. It emits an INFO log `feedback.submitted` with `feedback.report.id` and the report's trace/span.
2. If `includeDiagnostics` is true, it sends the in-memory ring: this SDK's own sanitized spans and logs from the last 5 minutes, at most 200 of each. Every item is tagged `feedback.report.id` and `feedback.excerpt = true`. Items that already went out continuously are not re-sent.
3. It flushes immediately. A server-requested backoff still applies.

### `telemetry: 'excerpt-only'` (for apps whose telemetry goes elsewhere)

Clubhouse already sends its own OpenTelemetry to each user's own Application Insights. With `excerpt-only`:

- **Nothing continuous.** Framebriar sends nothing continuously and metrics are disabled.
- **Local ring only.** Spans and logs only enter the local ring.
- **One request per report.** Data leaves only when the user submits a report with "Include recent app diagnostics" checked. Then one request carries the marker and that report's excerpt.
- **Unchecked sends nothing.** If the box is unchecked, nothing is sent, not even the marker.

Instrument only the moments that help triage feedback (agent start/stop, PTY respawns, git failures, renderer crashes), using codes. Keep the host's own OTel pipeline separate. Don't forward its spans into Framebriar.

## Outbox

`createOutbox({dir, access})` is a durable queue under `<dataDir>/outbox`:

- **Capacity:** ten reports / 32 MiB of PNG, the same as the browser.
- **Commit:** each report commits with one directory rename and is immutable afterwards: same UUID, notes, PNG hash and build/version on every retry. `enqueue` resolves only after the commit.
- **Retries:** delivery retries with persisted exponential backoff. 429/503 honour `retry-after`. `access-required` waits 5 minutes. Connecting again resumes delivery. A permanent rejection keeps the report as `blocked`; it is never deleted or retried in a loop.
- **Removal:** a report is removed only by a matching receipt (`onReceipt` / `outbox.onReceipt(fn)`) or by `clear()`. There's no age-based expiry, and Disconnect doesn't purge.
- **Status:** `status()` returns `{state, items, bytes, maxItems, maxBytes, blocked, retention: 'until-delivered-or-cleared'}`. When `enqueue` throws `storage-full`, keep the reviewed draft so the user can retry or export it.

## Storage layout

```
<dataDir>/enrollment.json        encrypted CAS record (0600)
<dataDir>/enrollment.json.lock   transient cross-process lock
<dataDir>/outbox/reports/<uuid>/{report.json, media.png, state.json}
```

## Testing

`tests/node-adapter.test.mjs` covers:

- the secure store's CAS, encryption refusal and lock recovery, using a fake `safeStorage` and real child processes;
- access flows against the real in-memory issuer;
- outbox durability across restart;
- end-to-end prepare → upload → receipt with correlated telemetry through the real intake and gateway handlers;
- excerpt-only consent behaviour.

Real Electron `safeStorage`, `capturePage` and live hosted enrollment are separate acceptance gates.
