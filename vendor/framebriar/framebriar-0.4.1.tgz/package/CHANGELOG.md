# Changelog: @masra91/framebriar

## 0.4.1 — 2026-10-17

- Browser, Node and Godot retain the redemption attempt until the enrollment is validated and saved. A temporary storage failure can recover with the same attempt, without spending another invitation use.
- Stale and superseded operations cannot clear a newer recovery attempt or schedule work after a reentrant stop. Explicit disconnect/clear and disposal discard the in-memory attempt; the existing retry window and invitation expiry limits remain unchanged.
- Includes `createGameTelemetry` from `@masra91/framebriar/browser/game-telemetry` and the accepted consent/lifecycle safeguards added since 0.4.0. Telemetry remains enrollment-gated and opt-in, with bounded queues, cancellation on opt-out and five-minute game-record expiry. The event catalog is in `docs/game-telemetry-v1.md`.

## 0.4.0 — 2026-10-17

First packaged release. It contains the SDK as of `main` 37282a3:

- Browser: enrollment, durable feedback, telemetry emitter, correlation, and console/error capture.
- Node/Electron main-process adapter: `safeStorage` secure store, outbox, capture and telemetry.
- `otlpExporterOptions` for bring-your-own OpenTelemetry.
- Cold-start resilience: 45 s access timeouts, and idempotent invite redemption with an attempt ID plus retries.
