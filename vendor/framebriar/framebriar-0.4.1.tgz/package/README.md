# @masra91/framebriar

Private feedback and telemetry SDK for Mason's apps. It's published to GitHub Packages from [masra91/framebriar](https://github.com/masra91/framebriar).

```sh
# .npmrc in the consuming project
@masra91:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_PACKAGES_TOKEN}
```

```sh
npm i @masra91/framebriar
```

| Import | What |
|---|---|
| `@masra91/framebriar/browser/playtest-access` | Invitation enrollment (30-day family, ≤1 h tokens) |
| `@masra91/framebriar/browser/durable-feedback` | Durable local outbox and delivery |
| `@masra91/framebriar/browser/local-export` | `prepareLocalFeedback` (screenshot + notes + context) |
| `@masra91/framebriar/browser/telemetry` | Built-in spans/logs/metrics emitter |
| `@masra91/framebriar/browser/game-telemetry` | `createGameTelemetry`: bounded game events and feedback correlation |
| `@masra91/framebriar/node` | Node/Electron main-process SDK (`createFramebriar`) |
| `@masra91/framebriar/otel` | `otlpExporterOptions(access, signal)` for your own OpenTelemetry exporters |
| `@masra91/framebriar/protocol` | Report schema and limits |

Docs: `adapters/node/README.md` in this package, and `docs/` in the source repo (general-feedback-v2, telemetry, correlation).

Game instrumentation is included from 0.4.1:

```js
import {createGameTelemetry} from '@masra91/framebriar/browser/game-telemetry';
```

See the [game semantics catalog](https://github.com/masra91/framebriar/blob/main/docs/game-telemetry-v1.md) for event fields and integration. The helper remains enrollment-gated, with independent bounded telemetry budgets and five-minute queued-record expiry. Turning telemetry off clears its buffers and cancels in-flight transport; it preserves feedback enrollment and the separate durable screenshot queue. Cancellation cannot recall bytes already received by the server.

Server-side apps that only send OpenTelemetry need no package. They use an ingestion key and the standard `OTEL_*` variables; see `docs/telemetry.md`.
